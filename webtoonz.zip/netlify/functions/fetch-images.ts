import { Handler } from "@netlify/functions";
import axios from "axios";
import { GoogleGenerativeAI } from "@google/generative-ai";
import LZString from "lz-string";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

export const handler: Handler = async (event, context) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  try {
    const { url } = JSON.parse(event.body || "{}");
    if (!url) {
      return { statusCode: 400, body: JSON.stringify({ error: "URL gereklidir" }) };
    }

    // 1. Check if it's an AI Studio "Share" URL with a hash
    if (url.includes('#')) {
      const hash = url.split('#')[1];
      if (hash && hash.length > 20) {
        try {
          const decoded = LZString.decompressFromEncodedURIComponent(hash);
          if (decoded) {
            const data = JSON.parse(decoded);
            const findImages = (obj: any): string[] => {
              let found: string[] = [];
              if (typeof obj === 'string') {
                if (obj.match(/https?:\/\/[^"'\s]+\.(?:jpg|jpeg|png|gif|webp|svg)/i)) found.push(obj);
              } else if (Array.isArray(obj)) {
                obj.forEach(item => found.push(...findImages(item)));
              } else if (typeof obj === 'object' && obj !== null) {
                Object.values(obj).forEach(val => found.push(...findImages(val)));
              }
              return found;
            };
            const images = findImages(data);
            if (images.length > 0) {
              return {
                statusCode: 200,
                body: JSON.stringify({ images: [...new Set(images)] })
              };
            }
          }
        } catch (e) {
          // Fallback to scraping
        }
      }
    }

    const response = await axios.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      },
      timeout: 10000 
    });

    const html = response.data;
    const imageRegex = /https?:\/\/[^"'\s]+(?:\.(?:jpg|jpeg|png|gif|webp|svg)|(?:\/api\/images\/[^"'\s]+)|(?:googleusercontent\.com\/[^"'\s]+))(?:\?[^"'\s]*)?/gi;
    let matches: string[] = html.match(imageRegex) || [];

    if (matches.length < 3 && process.env.GEMINI_API_KEY) {
      try {
        const prompt = `Aşağıdaki HTML içeriğindeki tüm doğrudan resim (image) URL'lerini ayıkla. Sadece JSON formatında bir string dizisi döndür. HTML: ${html.substring(0, 15000)}`; 
        const result = await model.generateContent(prompt);
        const aiText = result.response.text();
        const cleanText = aiText.replace(/```json|```/g, "").trim();
        const aiMatches = JSON.parse(cleanText);
        if (Array.isArray(aiMatches)) {
          matches = [...new Set([...matches, ...aiMatches])];
        }
      } catch (aiError) {
        console.error("Gemini scraping error:", aiError);
      }
    }
    
    const uniqueImages = [...new Set(matches)].filter(img => 
      !img.includes("favicon") && 
      !img.includes("logo") &&
      !img.includes("avatar")
    );

    return {
      statusCode: 200,
      body: JSON.stringify({ images: uniqueImages })
    };
  } catch (error: any) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message })
    };
  }
};
