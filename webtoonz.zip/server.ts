import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import axios from "axios";
import { GoogleGenerativeAI } from "@google/generative-ai";
import LZString from "lz-string";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Gemini for smart scraping
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' })); // Increase limit for HTML pasting

  // API Route to fetch images from a URL
  app.post("/api/fetch-images", async (req, res) => {
    const { url } = req.body;
    if (!url) {
      return res.status(400).json({ error: "URL gereklidir" });
    }

    try {
      // If the URL itself is a direct image link or an internal upload, return it immediately
      if (url.match(/\.(jpg|jpeg|png|gif|webp|svg|avif)(?:\?.*)?$/i) || url.includes('/uploads/')) {
        console.log("Direct image link detected, returning URL.");
        return res.json({ images: [url] });
      }

      // 1. Check if it's an AI Studio "Share" URL with a hash
      if (url.includes('#')) {
        const hash = url.split('#')[1];
        if (hash && hash.length > 20) {
          console.log("Attempting to decode hash data...");
          try {
            // Try decoding LZString (common in some templates)
            const decoded = LZString.decompressFromEncodedURIComponent(hash);
            if (decoded) {
              const data = JSON.parse(decoded);
              // Recursively find all strings that look like image URLs in the JSON
              const findImages = (obj: any): string[] => {
                let found: string[] = [];
                if (typeof obj === 'string') {
                  if (obj.match(/https?:\/\/[^"'\s]+\.(?:jpg|jpeg|png|gif|webp|svg)/i)) found.push(obj);
                } else if (Array.isArray(obj)) {
                  obj.forEach(item => found.push(...findImages(item)));
                } else if (typeof obj === 'object' && obj !== null) {
                  Object.values(obj).forEach(val => found.push(...findImages(val)));
                }
                return found;
              };
              const images = findImages(data);
              if (images.length > 0) {
                console.log(`Successfully decoded ${images.length} images from hash!`);
                return res.json({ images: [...new Set(images)] });
              }
            }
          } catch (e) {
            console.log("Hash decoding failed, falling back to scraping.");
          }
        }
      }

      console.log(`Fetching URL: ${url}`);
      const response = await axios.get(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        },
        timeout: 15000 
      });

      const html = response.data;
      if (typeof html !== 'string') {
        return res.status(400).json({ error: "URL geçerli bir sayfa döndürmedi." });
      }

      // 1. Try Regex first (Fast)
      const imageRegex = /https?:\/\/[^"'\s]+(?:\.(?:jpg|jpeg|png|gif|webp|svg|avif)|(?:\/api\/images\/[^"'\s]+)|(?:googleusercontent\.com\/[^"'\s]+)|(?:\/uploads\/[^"'\s]+))(?:\?[^"'\s]*)?/gi;
      let matches: string[] = html.match(imageRegex) || [];

      // 2. If regex finds too few or nothing, use Gemini to analyze (Smart)
      if (matches.length < 3 && process.env.GEMINI_API_KEY) {
        console.log("Regex found few images, using Gemini AI to analyze HTML...");
        try {
          const prompt = `Aşağıdaki HTML içeriğindeki tüm doğrudan resim (image) URL'lerini ayıkla. 
          Özellikle <img> etiketlerindeki src'leri, arka plan resimlerini ve resim dosyalarına (.jpg, .png, .webp vb.) veya resim servislerine (api/images gibi) giden linkleri bul.
          Sadece JSON formatında bir string dizisi döndür. Başka açıklama yapma.
          HTML: ${html.substring(0, 25000)}`; 

          const result = await model.generateContent(prompt);
          const aiText = result.response.text();
          const cleanText = aiText.replace(/```json|```/g, "").trim();
          const aiMatches = JSON.parse(cleanText);
          if (Array.isArray(aiMatches)) {
            matches = [...new Set([...matches, ...aiMatches])];
          }
        } catch (aiError) {
          console.error("Gemini scraping error:", aiError);
        }
      }
      
      const uniqueImages = [...new Set(matches)].filter(img => 
        !img.includes("favicon") && 
        !img.includes("logo") &&
        !img.includes("avatar") &&
        !img.includes("dicebear.com") &&
        !img.includes("gstatic.com")
      );

      console.log(`Found ${uniqueImages.length} images`);
      res.json({ images: uniqueImages });
    } catch (error: any) {
      console.error("Fetch error:", error.message);
      let message = "Resimler çekilirken bir hata oluştu.";
      if (error.response) {
        if (error.response.status === 403 || error.response.status === 401) {
          message = "Bu siteye erişim engellendi. Lütfen 'Shared App' linkini kullandığınızdan emin olun.";
        } else if (error.response.status === 404) {
          message = "Sayfa bulunamadı. Lütfen linki kontrol edin.";
        }
      }
      res.status(500).json({ error: message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  // Proxy route for images to bypass CORS or referrer issues
  app.get("/api/proxy-image", async (req, res) => {
    const { url } = req.query;
    if (!url || typeof url !== 'string') {
      return res.status(400).send("URL gereklidir");
    }

    try {
      console.log(`Proxying image: ${url}`);
      const targetUrl = new URL(url);
      const response = await axios.get(url, {
        responseType: 'arraybuffer',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
          'Referer': targetUrl.origin,
          'Origin': targetUrl.origin
        },
        timeout: 15000,
        maxRedirects: 5
      });

      const contentType = response.headers['content-type'];
      if (contentType) res.setHeader('Content-Type', contentType);
      res.setHeader('Cache-Control', 'public, max-age=86400');
      res.send(response.data);
    } catch (error: any) {
      console.error(`Proxy error for ${url}:`, error.message);
      res.status(500).send("Resim yüklenemedi");
    }
  });
}

startServer();
