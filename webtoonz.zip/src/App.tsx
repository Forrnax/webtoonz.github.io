import React, { useState, useEffect, useMemo } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate, useParams, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { 
  BookOpen, 
  LayoutDashboard, 
  LogIn, 
  LogOut, 
  Plus, 
  Search, 
  User as UserIcon,
  ChevronRight,
  MessageSquare,
  Clock,
  Edit,
  Trash2,
  Image as ImageIcon,
  FileText,
  Heart,
  Star,
  Eye,
  ThumbsUp,
  Settings,
  Sparkles,
  History,
  Bookmark,
  Bell,
  Calendar,
  TrendingUp,
  Zap,
  ChevronLeft,
  Camera,
  Lock,
  Mail,
  User as UserSettingsIcon,
  Layout,
  Shield,
  ShieldCheck,
  Users,
  Upload,
  Loader2,
  AlertTriangle,
  RefreshCw,
  Flag
} from 'lucide-react';
import { 
  onAuthStateChanged, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut,
  updateProfile,
  updateEmail,
  updatePassword,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  User
} from 'firebase/auth';
import { 
  collection, 
  query, 
  where, 
  orderBy, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  getDoc,
  getDocs,
  setDoc,
  serverTimestamp,
  getDocFromServer,
  increment,
  limit,
  Timestamp,
  collectionGroup
} from 'firebase/firestore';
import { auth, db } from './lib/firebase';
import { cn } from './lib/utils';
import { Webtoon, Chapter, Comment, UserProfile, Favorite, Rating, Progress, ChapterLike, AppNotification } from './types';
import { format } from 'date-fns';
import ReactMarkdown from 'react-markdown';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";

// --- Constants ---
const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY || "";
const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });

const GENRES = [
  'Aksiyon', 'Romantik', 'Fantastik', 'Dram', 'Komedi', 
  'Korku', 'Bilim Kurgu', 'Yaşamdan Kesitler', 'Gerilim', 
  'Gizem', 'Spor', 'Süper Kahraman', 'Macera', 'Tarihi'
];

const DAYS = [
  { id: 'Monday', label: 'Pazartesi' },
  { id: 'Tuesday', label: 'Salı' },
  { id: 'Wednesday', label: 'Çarşamba' },
  { id: 'Thursday', label: 'Perşembe' },
  { id: 'Friday', label: 'Cuma' },
  { id: 'Saturday', label: 'Cumartesi' },
  { id: 'Sunday', label: 'Pazar' }
];

// --- Error Handling ---

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errorMessage = error instanceof Error ? error.message : String(error);
  const isQuotaExceeded = errorMessage.includes('Quota exceeded') || errorMessage.includes('quota');

  const errInfo: FirestoreErrorInfo = {
    error: errorMessage,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  
  // Dispatch a custom event for global error handling
  window.dispatchEvent(new CustomEvent('firestore-error', { detail: errInfo }));
  
  // If it's a quota error, we don't necessarily want to crash the whole app with a throw
  // but we want to stop the current operation.
  if (isQuotaExceeded) {
    return; 
  }

  throw new Error(JSON.stringify(errInfo));
}

const QuotaErrorDisplay = () => (
  <div className="flex min-h-[60vh] flex-col items-center justify-center p-8 text-center">
    <div className="mb-6 rounded-full bg-orange-500/10 p-6 ring-1 ring-orange-500/20">
      <Zap className="h-12 w-12 text-orange-500" />
    </div>
    <h2 className="mb-4 text-2xl font-black text-white font-display uppercase tracking-tight">Günlük Kota Doldu</h2>
    <p className="max-w-md text-zinc-400 leading-relaxed">
      WebtoonZ şu an çok popüler! Ücretsiz veritabanı kotamız bugünlük doldu. 
      Sistem Türkiye saatiyle gece yarısı otomatik olarak sıfırlanacaktır.
    </p>
    <div className="mt-8 flex flex-col gap-4">
      <div className="rounded-xl bg-zinc-900/50 p-4 border border-zinc-800">
        <p className="text-xs text-zinc-500 font-mono">Hata: Quota limit exceeded (free tier)</p>
      </div>
      <button 
        onClick={() => window.location.reload()}
        className="rounded-xl bg-orange-600 px-8 py-3 font-bold text-white hover:bg-orange-500 transition-all"
      >
        Sayfayı Yenile
      </button>
    </div>
  </div>
);

// --- Components ---

const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const Navbar = ({ user, profile }: { user: User | null, profile: UserProfile | null }) => {
  const location = useLocation();
  const isReader = location.pathname.includes('/chapter/');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);

  // Expose showAuthModal to window for guest banner
  useEffect(() => {
    (window as any).showAuthModal = () => setShowAuthModal(true);
    return () => { delete (window as any).showAuthModal; };
  }, []);

  useEffect(() => {
    if (!user) {
      setNotifications([]);
      return;
    }
    const q = query(
      collection(db, 'notifications'), 
      where('userId', '==', user.uid), 
      orderBy('createdAt', 'desc'),
      limit(10)
    );
    getDocs(q).then((snapshot) => {
      setNotifications(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as AppNotification)));
    }).catch((error) => {
      console.error('Notification error:', error);
    });
    return () => {};
  }, [user]);

  if (isReader) return null;

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const handleLogin = async () => {
    if (isLoggingIn) return;
    setIsLoggingIn(true);
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error: any) {
      if (error.code === 'auth/popup-closed-by-user' || error.code === 'auth/cancelled-popup-request') {
        console.warn("Login popup closed or cancelled.");
      } else {
        console.error("Login failed", error);
      }
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = () => signOut(auth);

  const markAsRead = async (notifId: string) => {
    try {
      await updateDoc(doc(db, 'notifications', notifId), { isRead: true });
    } catch (error) {}
  };

  return (
    <>
      <nav className="sticky top-0 z-50 w-full border-b border-zinc-800 bg-zinc-950/80 backdrop-blur-md">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2 text-2xl font-black tracking-tighter text-white font-display">
          <BookOpen className="h-7 w-7 text-orange-500" />
          <span>WEBTOON<span className="text-orange-500">Z</span></span>
        </Link>

        <div className="flex items-center gap-4">
          {user ? (
            <div className="flex items-center gap-3">
              {/* Notifications */}
              <div className="relative">
                <button 
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-zinc-900 text-zinc-400 transition-all hover:bg-zinc-800 hover:text-white"
                >
                  <Bell className="h-5 w-5" />
                  {unreadCount > 0 && (
                    <span className="absolute top-2 right-2 flex h-2 w-2">
                      <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-orange-400 opacity-75"></span>
                      <span className="relative inline-flex h-2 w-2 rounded-full bg-orange-500"></span>
                    </span>
                  )}
                </button>

                {showNotifications && (
                  <div className="absolute right-0 mt-2 w-80 rounded-2xl border border-zinc-800 bg-zinc-900 p-2 shadow-2xl">
                    <div className="mb-2 flex items-center justify-between px-3 py-2">
                      <h3 className="text-xs font-black uppercase text-zinc-500 tracking-widest">Bildirimler</h3>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      {notifications.length === 0 ? (
                        <div className="py-8 text-center text-xs text-zinc-600">Henüz bildirim yok.</div>
                      ) : (
                        notifications.map(n => (
                          <Link 
                            key={n.id} 
                            to={`/webtoon/${n.webtoonId}`}
                            onClick={() => { markAsRead(n.id); setShowNotifications(false); }}
                            className={cn(
                              "flex flex-col gap-1 rounded-xl p-3 transition-all hover:bg-zinc-800",
                              !n.isRead && "bg-orange-500/5"
                            )}
                          >
                            <p className="text-xs font-bold text-white">
                              {n.webtoonTitle} <span className="text-orange-500">Bölüm {n.chapterNumber}</span> yayınlandı!
                            </p>
                            <p className="text-[10px] text-zinc-500">{format(n.createdAt?.toDate?.() || new Date(), 'dd MMM, HH:mm')}</p>
                          </Link>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>

              <Link to="/profile" className="flex h-10 w-10 items-center justify-center overflow-hidden rounded-xl bg-zinc-900 ring-1 ring-zinc-800 transition-all hover:ring-orange-500/50">
                <img src={user.photoURL || undefined} alt={user.displayName || ''} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
              </Link>
              
              {profile?.role === 'admin' && (
                <Link to="/admin" className="flex h-10 w-10 items-center justify-center rounded-xl bg-zinc-900 text-zinc-400 transition-all hover:bg-zinc-800 hover:text-white">
                  <LayoutDashboard className="h-5 w-5" />
                </Link>
              )}
              <button 
                onClick={handleLogout}
                className="flex h-10 w-10 items-center justify-center rounded-xl bg-zinc-900 text-zinc-400 transition-all hover:bg-red-500/10 hover:text-red-500"
              >
                <LogOut className="h-5 w-5" />
              </button>
            </div>
          ) : (
            <button 
              onClick={() => setShowAuthModal(true)}
              className="flex items-center gap-2 rounded-xl bg-orange-600 px-6 py-2.5 text-sm font-bold text-white transition-all hover:bg-orange-500"
            >
              <LogIn className="h-4 w-4" />
              Giriş Yap
            </button>
          )}
        </div>
      </div>
    </nav>

    {showAuthModal && (
      <AuthModal 
        onClose={() => setShowAuthModal(false)} 
        onGoogleLogin={handleLogin}
        isLoggingIn={isLoggingIn}
      />
    )}
  </>
  );
};

const AuthModal = ({ onClose, onGoogleLogin, isLoggingIn }: { onClose: () => void, onGoogleLogin: () => void, isLoggingIn: boolean }) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      if (isSignUp) {
        await createUserWithEmailAndPassword(auth, email, password);
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
      onClose();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="w-full max-w-md overflow-hidden rounded-3xl border border-zinc-800 bg-zinc-900 shadow-2xl">
        <div className="p-8">
          <div className="mb-8 flex items-center justify-between">
            <h2 className="text-2xl font-black text-white font-display tracking-tight">
              {isSignUp ? 'Kayıt Ol' : 'Giriş Yap'}
            </h2>
            <button onClick={onClose} className="text-zinc-500 hover:text-white">
              <Plus className="h-6 w-6 rotate-45" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest">E-posta</label>
              <input 
                required
                type="email"
                className="rounded-xl border border-zinc-800 bg-zinc-950 p-3 text-white focus:border-orange-500 focus:outline-none"
                value={email}
                onChange={e => setEmail(e.target.value)}
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Şifre</label>
              <input 
                required
                type="password"
                className="rounded-xl border border-zinc-800 bg-zinc-950 p-3 text-white focus:border-orange-500 focus:outline-none"
                value={password}
                onChange={e => setPassword(e.target.value)}
              />
            </div>

            {error && <p className="text-xs font-bold text-red-500">{error}</p>}

            <button 
              disabled={loading}
              className="mt-2 rounded-xl bg-orange-600 py-3 font-bold text-white transition-all hover:bg-orange-500 disabled:opacity-50"
            >
              {loading ? 'İşlem yapılıyor...' : (isSignUp ? 'Kayıt Ol' : 'Giriş Yap')}
            </button>
          </form>

          <div className="my-8 flex items-center gap-4">
            <div className="h-px flex-1 bg-zinc-800" />
            <span className="text-[10px] font-black uppercase text-zinc-600 tracking-widest">VEYA</span>
            <div className="h-px flex-1 bg-zinc-800" />
          </div>

          <button 
            onClick={onGoogleLogin}
            disabled={isLoggingIn}
            className="flex w-full items-center justify-center gap-3 rounded-xl border border-zinc-800 bg-zinc-950 py-3 text-sm font-bold text-white transition-all hover:bg-zinc-800 disabled:opacity-50"
          >
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="h-5 w-5" />
            Google ile Devam Et
          </button>

          <p className="mt-8 text-center text-xs text-zinc-500">
            {isSignUp ? 'Zaten hesabın var mı?' : 'Henüz hesabın yok mu?'}
            <button 
              onClick={() => setIsSignUp(!isSignUp)}
              className="ml-2 font-bold text-orange-500 hover:underline"
            >
              {isSignUp ? 'Giriş Yap' : 'Kayıt Ol'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

// --- Pages ---

const Skeleton = ({ className }: { className?: string }) => (
  <div className={cn("animate-pulse rounded-xl bg-zinc-900", className)} />
);

const WebtoonCard = React.memo(({ item }: { item: Webtoon }) => (
  <Link to={`/webtoon/${item.id}`} className="group flex flex-col gap-2">
    <div className="relative aspect-[3/4] overflow-hidden rounded-2xl ring-1 ring-zinc-900 transition-all group-hover:ring-orange-500/50">
      <img 
        src={item.coverUrl || undefined} 
        className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110" 
        referrerPolicy="no-referrer" 
        loading="lazy"
        decoding="async"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
      <div className="absolute bottom-2 left-2 flex flex-wrap gap-1 opacity-0 transition-all group-hover:opacity-100">
        {item.genres?.slice(0, 2).map(g => (
          <span key={g} className="rounded bg-orange-600 px-1.5 py-0.5 text-[8px] font-black text-white uppercase">{g}</span>
        ))}
      </div>
    </div>
    <h3 className="text-sm font-bold text-white line-clamp-1 group-hover:text-orange-500 transition-colors">{item.title}</h3>
    <div className="flex items-center gap-2">
      <span className="text-[10px] font-black uppercase text-zinc-500 tracking-widest">{item.type}</span>
      <span className="text-zinc-700">•</span>
      <div className="flex items-center gap-0.5 text-[10px] font-bold text-orange-500">
        <Star className="h-2.5 w-2.5 fill-orange-500" />
        {(item.ratingSum && item.ratingCount) ? (item.ratingSum / item.ratingCount).toFixed(1) : '0.0'}
      </div>
    </div>
  </Link>
));

const HomePage = ({ user }: { user: User | null }) => {
  const [webtoons, setWebtoons] = useState<Webtoon[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [recentProgress, setRecentProgress] = useState<Progress[]>([]);
  const [favorites, setFavorites] = useState<Favorite[]>([]);
  const [sortBy, setSortBy] = useState<'newest' | 'popular' | 'trending'>('newest');
  const [activeSlide, setActiveSlide] = useState(0);
  const [selectedDay, setSelectedDay] = useState<string>(DAYS[new Date().getDay() === 0 ? 6 : new Date().getDay() - 1].id);
  const [upcomingChapters, setUpcomingChapters] = useState<Chapter[]>([]);

  useEffect(() => {
    const q = query(
      collection(db, 'webtoons'), 
      orderBy('createdAt', 'desc'),
      limit(24)
    );
    
    getDocs(q).then((snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Webtoon));
      setWebtoons(data);
      setLoading(false);
    }).catch((error) => {
      setLoading(false);
      handleFirestoreError(error, OperationType.LIST, 'webtoons');
    });

    // Fetch upcoming chapters
    const now = new Date();
    const upcomingQ = query(
      collectionGroup(db, 'chapters'),
      where('publishAt', '>', Timestamp.fromDate(now)),
      orderBy('publishAt', 'asc'),
      limit(10)
    );
    getDocs(upcomingQ).then((snapshot) => {
      setUpcomingChapters(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Chapter)));
    }).catch((error) => {
      console.error('Upcoming chapters error:', error);
    });

    return () => {};
  }, []);

  useEffect(() => {
    if (!user) {
      setRecentProgress([]);
      setFavorites([]);
      return;
    }

    const progressQ = query(
      collection(db, 'progress'), 
      where('userId', '==', user.uid), 
      orderBy('updatedAt', 'desc'),
      limit(6)
    );
    getDocs(progressQ).then((snapshot) => {
      setRecentProgress(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Progress)));
    }).catch(err => console.error('Progress error:', err));

    const favQ = query(collection(db, 'favorites'), where('userId', '==', user.uid), limit(12));
    getDocs(favQ).then((snapshot) => {
      setFavorites(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Favorite)));
    }).catch(err => console.error('Favorites error:', err));

    return () => {};
  }, [user]);

  const filteredWebtoons = webtoons.filter(item => {
    const matchesGenre = !selectedGenre || (item.genres && item.genres.includes(selectedGenre));
    const matchesSearch = !searchQuery || item.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesGenre && matchesSearch;
  });

  const sortedWebtoons = useMemo(() => {
    return [...filteredWebtoons].sort((a, b) => {
      if (sortBy === 'popular') return (b.viewCount || 0) - (a.viewCount || 0);
      if (sortBy === 'trending') return (b.ratingSum || 0) - (a.ratingSum || 0);
      return (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0);
    });
  }, [filteredWebtoons, sortBy]);

  const sliderItems = useMemo(() => webtoons.slice(0, 5), [webtoons]);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Skeleton className="mb-12 h-[300px] w-full md:h-[450px]" />
        <div className="mb-12">
          <Skeleton className="mb-6 h-8 w-48" />
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
            {[...Array(6)].map((_, i) => <Skeleton key={i} className="aspect-[3/4] w-full" />)}
          </div>
        </div>
        <div className="mb-12">
          <Skeleton className="mb-6 h-8 w-48" />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Guest Welcome Banner */}
      {!user && (
        <div className="mb-12 overflow-hidden rounded-3xl bg-gradient-to-r from-orange-600 to-orange-800 p-8 text-white shadow-2xl md:p-12">
          <div className="flex flex-col items-center justify-between gap-8 md:flex-row">
            <div className="max-w-2xl text-center md:text-left">
              <h1 className="text-3xl font-black md:text-5xl font-display tracking-tight">Hoş Geldiniz! 🎉</h1>
              <p className="mt-4 text-lg font-medium text-orange-100">
                En sevdiğiniz webtoon ve romanları tamamen ücretsiz ve herkese açık bir şekilde okuyabilirsiniz. 
                Okuma geçmişinizi kaydetmek ve favorilerinize eklemek için giriş yapmayı unutmayın!
              </p>
            </div>
            <button 
              onClick={() => (window as any).showAuthModal?.()}
              className="shrink-0 rounded-2xl bg-white px-8 py-4 text-lg font-black text-orange-600 shadow-xl transition-all hover:scale-105 hover:bg-zinc-100 active:scale-95"
            >
              Hemen Katıl
            </button>
          </div>
        </div>
      )}

      {/* Hero Slider */}
      {sliderItems.length > 0 && (
        <div className="relative mb-12 h-[300px] w-full overflow-hidden rounded-3xl md:h-[450px]">
          <div 
            className="flex h-full transition-transform duration-700 ease-in-out"
            style={{ transform: `translateX(-${activeSlide * 100}%)` }}
          >
            {sliderItems.map((item, idx) => (
              <div key={item.id} className="relative h-full w-full shrink-0">
                <img src={item.coverUrl || undefined} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/40 to-transparent" />
                <div className="absolute bottom-0 left-0 p-6 md:p-12">
                  <div className="mb-3 flex items-center gap-2">
                    <span className="rounded-lg bg-orange-600 px-3 py-1 text-[10px] font-black uppercase tracking-widest text-white">ÖNE ÇIKAN</span>
                    <span className="text-xs font-bold text-zinc-400">{item.genres?.slice(0, 2).join(' • ')}</span>
                  </div>
                  <h2 className="mb-4 text-3xl font-black text-white font-display tracking-tight md:text-6xl">{item.title}</h2>
                  <Link to={`/webtoon/${item.id}`} className="inline-flex items-center gap-2 rounded-xl bg-white px-8 py-3 text-sm font-black text-black transition-all hover:bg-orange-500 hover:text-white">
                    Şimdi Oku
                    <ChevronRight className="h-4 w-4" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
          <div className="absolute bottom-6 right-6 flex gap-2">
            {sliderItems.map((_, idx) => (
              <button 
                key={idx} 
                onClick={() => setActiveSlide(idx)}
                className={cn(
                  "h-1.5 rounded-full transition-all",
                  activeSlide === idx ? "w-8 bg-orange-500" : "w-2 bg-zinc-600"
                )}
              />
            ))}
          </div>
        </div>
      )}

      {/* Weekly Schedule */}
      <div className="mb-12">
        <h2 className="mb-6 flex items-center gap-2 text-xl font-bold text-white font-display">
          <Calendar className="h-5 w-5 text-orange-500" />
          Yayın Takvimi
        </h2>
        <div className="mb-6 flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {DAYS.map(day => (
            <button 
              key={day.id}
              onClick={() => setSelectedDay(day.id)}
              className={cn(
                "whitespace-nowrap rounded-xl px-4 py-2 text-xs font-bold transition-all",
                selectedDay === day.id ? "bg-zinc-100 text-black" : "bg-zinc-900 text-zinc-500 hover:text-white"
              )}
            >
              {day.label}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {(() => {
            const scheduledWebtoons = webtoons.filter(w => {
              // Check if it has an upcoming chapter on this day
              const hasUpcomingOnDay = upcomingChapters.some(ch => {
                if (ch.webtoonId !== w.id) return false;
                const publishDate = ch.publishAt.toDate();
                const dayName = format(publishDate, 'EEEE'); // e.g., 'Monday'
                return dayName === selectedDay;
              });
              return hasUpcomingOnDay;
            });

            if (scheduledWebtoons.length === 0) {
              return <div className="col-span-full py-8 text-center text-xs text-zinc-600">Bu gün için planlanmış yeni bölüm bulunamadı.</div>;
            }

            return scheduledWebtoons.map(item => (
              <Link key={item.id} to={`/webtoon/${item.id}`} className="group flex flex-col gap-2">
                <div className="relative aspect-[3/4] overflow-hidden rounded-2xl ring-1 ring-zinc-900">
                  <img src={item.coverUrl || undefined} className="h-full w-full object-cover transition-transform group-hover:scale-105" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
                  <div className="absolute top-2 right-2 rounded-lg bg-orange-600 px-2 py-1 text-[8px] font-black text-white shadow-lg">YAKINDA</div>
                </div>
                <h3 className="text-xs font-bold text-white line-clamp-1">{item.title}</h3>
                {upcomingChapters.filter(ch => ch.webtoonId === item.id && format(ch.publishAt.toDate(), 'EEEE') === selectedDay).map(ch => (
                  <p key={ch.id} className="text-[10px] font-medium text-orange-500">Bölüm {ch.number} • {format(ch.publishAt.toDate(), 'HH:mm')}</p>
                ))}
              </Link>
            ));
          })()}
        </div>
      </div>

      {/* Continue Reading Section */}
      {recentProgress.length > 0 ? (
        <div className="mb-12">
          <h2 className="mb-6 flex items-center gap-2 text-xl font-bold text-white font-display">
            <History className="h-5 w-5 text-orange-500" />
            Okumaya Devam Et
          </h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {recentProgress.map(prog => {
              const item = webtoons.find(w => w.id === prog.webtoonId);
              if (!item) return null;
              return (
                <Link key={prog.id} to={`/webtoon/${item.id}/chapter/${prog.chapterId}`} className="flex items-center gap-4 rounded-2xl border border-zinc-900 bg-zinc-900/30 p-3 transition-all hover:bg-zinc-900/50">
                  <img src={item.coverUrl || undefined} className="h-16 w-12 rounded-lg object-cover" referrerPolicy="no-referrer" />
                  <div className="flex flex-col">
                    <span className="text-sm font-bold text-white line-clamp-1">{item.title}</span>
                    <span className="text-xs text-zinc-500">Bölüm {prog.chapterNumber}</span>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      ) : !user && (
        <div className="mb-12 rounded-2xl border border-dashed border-zinc-800 p-8 text-center">
          <History className="mx-auto mb-3 h-8 w-8 text-zinc-700" />
          <p className="text-sm font-medium text-zinc-500">Okuma geçmişinizi takip etmek için giriş yapın.</p>
        </div>
      )}

      {/* Favorites Section */}
      {user && favorites.length > 0 && (
        <div className="mb-12">
          <h2 className="mb-6 flex items-center gap-2 text-xl font-bold text-white font-display">
            <Bookmark className="h-5 w-5 text-orange-500" />
            Favorilerim
          </h2>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
            {favorites.map(fav => {
              const item = webtoons.find(w => w.id === fav.webtoonId);
              if (!item) return null;
              return <WebtoonCard key={fav.id} item={item} />;
            })}
          </div>
        </div>
      )}

      <div className="mb-10 flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
        <div className="space-y-1">
          <h1 className="text-4xl font-black text-white font-display tracking-tight">Keşfet</h1>
          <div className="mt-4 flex items-center gap-4">
            <button 
              onClick={() => setSortBy('newest')}
              className={cn("text-xs font-bold transition-all", sortBy === 'newest' ? "text-orange-500" : "text-zinc-500 hover:text-white")}
            >
              En Yeniler
            </button>
            <button 
              onClick={() => setSortBy('popular')}
              className={cn("text-xs font-bold transition-all", sortBy === 'popular' ? "text-orange-500" : "text-zinc-500 hover:text-white")}
            >
              Popüler
            </button>
            <button 
              onClick={() => setSortBy('trending')}
              className={cn("text-xs font-bold transition-all", sortBy === 'trending' ? "text-orange-500" : "text-zinc-500 hover:text-white")}
            >
              Trendler
            </button>
          </div>
        </div>
        <div className="relative group">
          <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500 transition-colors group-focus-within:text-orange-500" />
          <input 
            type="text" 
            placeholder="Başlığa göre ara..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-11 rounded-xl border border-zinc-800 bg-zinc-900/50 pl-11 pr-4 text-sm text-white placeholder:text-zinc-600 focus:border-orange-500 focus:bg-zinc-900 focus:outline-none transition-all md:w-80"
          />
        </div>
      </div>

      {/* Genre Filter Bar */}
      <div className="mb-10 flex flex-wrap gap-2 overflow-x-auto pb-4 scrollbar-hide">
        <button 
          onClick={() => setSelectedGenre(null)}
          className={cn(
            "whitespace-nowrap rounded-xl px-5 py-2 text-xs font-bold transition-all duration-200 border",
            !selectedGenre 
              ? "bg-orange-600 border-orange-500 text-white shadow-[0_0_15px_rgba(234,88,12,0.3)]" 
              : "bg-zinc-900 border-zinc-800 text-zinc-400 hover:border-zinc-700 hover:text-white"
          )}
        >
          Hepsi
        </button>
        {GENRES.map(genre => (
          <button 
            key={genre}
            onClick={() => setSelectedGenre(genre)}
            className={cn(
              "whitespace-nowrap rounded-xl px-5 py-2 text-xs font-bold transition-all duration-200 border",
              selectedGenre === genre 
                ? "bg-orange-600 border-orange-500 text-white shadow-[0_0_15px_rgba(234,88,12,0.3)]" 
                : "bg-zinc-900 border-zinc-800 text-zinc-400 hover:border-zinc-700 hover:text-white"
            )}
          >
            {genre}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
        {sortedWebtoons.map((item) => (
          <WebtoonCard key={item.id} item={item} />
        ))}
      </div>
    </div>
  );
};

const WebtoonDetail = ({ user, profile }: { user: User | null, profile: UserProfile | null }) => {
  const { id } = useParams();
  const [webtoon, setWebtoon] = useState<Webtoon | null>(null);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [loading, setLoading] = useState(true);
  const [isFavorite, setIsFavorite] = useState(false);
  const [userRating, setUserRating] = useState<number | null>(null);

  useEffect(() => {
    if (!id) return;
    const docRef = doc(db, 'webtoons', id);
    
    // Increment view count
    updateDoc(docRef, { viewCount: increment(1) }).catch(() => {});

    getDoc(docRef).then((snapshot) => {
      if (snapshot.exists()) {
        setWebtoon({ id: snapshot.id, ...snapshot.data() } as Webtoon);
      }
    }).catch(err => {
      setLoading(false);
      handleFirestoreError(err, OperationType.GET, `webtoons/${id}`);
    });

    const q = query(collection(db, `webtoons/${id}/chapters`), orderBy('number', 'desc'));
    getDocs(q).then((snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Chapter));
      setChapters(data);
      setLoading(false);
    }).catch(err => {
      setLoading(false);
      handleFirestoreError(err, OperationType.LIST, `webtoons/${id}/chapters`);
    });

    return () => {};
  }, [id]);

  useEffect(() => {
    if (!user || !id) return;
    
    const favQ = query(collection(db, 'favorites'), where('userId', '==', user.uid), where('webtoonId', '==', id));
    getDocs(favQ).then((snapshot) => {
      setIsFavorite(!snapshot.empty);
    }).catch(err => console.error('Favorite check error:', err));

    const ratingQ = query(collection(db, 'ratings'), where('userId', '==', user.uid), where('webtoonId', '==', id));
    getDocs(ratingQ).then((snapshot) => {
      if (!snapshot.empty) {
        setUserRating(snapshot.docs[0].data().score);
      }
    }).catch(err => console.error('Rating check error:', err));

    return () => {};
  }, [user, id]);

  const toggleFavorite = async () => {
    if (!user || !id) return;
    try {
      const favQ = query(collection(db, 'favorites'), where('userId', '==', user.uid), where('webtoonId', '==', id));
      const snapshot = await getDocFromServer(doc(db, 'favorites', `${user.uid}_${id}`));
      
      if (isFavorite) {
        await deleteDoc(doc(db, 'favorites', `${user.uid}_${id}`));
      } else {
        await setDoc(doc(db, 'favorites', `${user.uid}_${id}`), {
          userId: user.uid,
          webtoonId: id,
          createdAt: serverTimestamp()
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'favorites');
    }
  };

  const handleRate = async (score: number) => {
    if (!user || !id) return;
    try {
      const ratingRef = doc(db, 'ratings', `${user.uid}_${id}`);
      const webtoonRef = doc(db, 'webtoons', id);
      
      if (userRating) {
        // Update existing rating
        const diff = score - userRating;
        await updateDoc(ratingRef, { score, updatedAt: serverTimestamp() });
        await updateDoc(webtoonRef, { ratingSum: increment(diff) });
      } else {
        // New rating
        await setDoc(ratingRef, {
          userId: user.uid,
          webtoonId: id,
          score,
          createdAt: serverTimestamp()
        });
        await updateDoc(webtoonRef, { 
          ratingSum: increment(score),
          ratingCount: increment(1)
        });
      }
      setUserRating(score);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'ratings');
    }
  };

  if (loading) return <div className="flex h-64 items-center justify-center text-zinc-500">Yükleniyor...</div>;
  if (!webtoon) return <div className="flex h-64 items-center justify-center text-zinc-500">İçerik bulunamadı.</div>;

  const avgRating = webtoon.ratingCount ? (webtoon.ratingSum! / webtoon.ratingCount!).toFixed(1) : '0.0';

  const isAdmin = profile?.role === 'admin';
  const visibleChapters = chapters.filter(ch => {
    if (isAdmin) return true;
    if (!ch.publishAt) return true;
    return ch.publishAt.toDate() <= new Date();
  });

  return (
    <div className="relative min-h-screen">
      <Helmet>
        <title>{`${webtoon.title} - WebtoonZ`}</title>
        <meta name="description" content={webtoon.description?.substring(0, 160)} />
      </Helmet>

      {/* Hero Background Blur */}
      <div className="absolute inset-0 -z-10 h-[500px] w-full overflow-hidden">
        <img 
          src={webtoon.coverUrl || undefined} 
          className="h-full w-full object-cover opacity-20 blur-3xl scale-110" 
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-zinc-950/50 to-zinc-950" />
      </div>

      <div className="container mx-auto px-4 py-8 md:py-16">
        <div className="flex flex-col gap-8 md:flex-row md:items-start">
          <div className="w-full shrink-0 md:w-72">
            <div className="relative aspect-[3/4] w-full overflow-hidden rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] ring-1 ring-white/10">
              <img 
                src={webtoon.coverUrl || undefined} 
                alt={webtoon.title} 
                className="h-full w-full object-cover"
                referrerPolicy="no-referrer"
                decoding="async"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
            </div>
            <button 
              onClick={() => user ? toggleFavorite() : (window as any).showAuthModal?.()}
              className={cn(
                "mt-6 flex w-full items-center justify-center gap-2 rounded-2xl py-4 text-sm font-black transition-all shadow-xl",
                isFavorite 
                  ? "bg-zinc-900 text-orange-500 border border-orange-500/30" 
                  : "bg-orange-600 text-white hover:bg-orange-500 hover:scale-[1.02] active:scale-95"
              )}
            >
              <Heart className={cn("h-5 w-5", isFavorite && "fill-orange-500")} />
              {isFavorite ? 'Kütüphaneden Çıkar' : 'Kütüphaneye Ekle'}
            </button>
          </div>
          <div className="flex flex-col gap-6">
            <div className="flex flex-wrap items-center gap-3">
              <span className={cn(
                "rounded-full px-4 py-1.5 text-[10px] font-black uppercase tracking-widest shadow-lg",
                webtoon.type === 'webtoon' ? "bg-orange-600 text-white" : "bg-blue-600 text-white"
              )}>
                {webtoon.type}
              </span>
              <span className="rounded-full bg-zinc-900/80 px-4 py-1.5 text-[10px] font-black text-zinc-400 uppercase tracking-widest ring-1 ring-zinc-800 backdrop-blur-md">
                {webtoon.status === 'ongoing' ? 'Devam Ediyor' : 'Tamamlandı'}
              </span>
              <div className="flex items-center gap-1.5 rounded-full bg-zinc-900/80 px-4 py-1.5 text-[10px] font-black text-orange-500 ring-1 ring-zinc-800 backdrop-blur-md">
                <Star className="h-3.5 w-3.5 fill-orange-500" />
                {avgRating} <span className="text-zinc-500 font-bold ml-1">({webtoon.ratingCount || 0})</span>
              </div>
              <div className="flex items-center gap-1.5 rounded-full bg-zinc-900/80 px-4 py-1.5 text-[10px] font-black text-zinc-400 ring-1 ring-zinc-800 backdrop-blur-md">
                <Eye className="h-3.5 w-3.5" />
                {webtoon.viewCount || 0}
              </div>
            </div>
            <div className="space-y-2">
              <h1 className="text-4xl font-black text-white md:text-7xl font-display tracking-tight leading-none">{webtoon.title}</h1>
              <p className="text-xl font-bold text-orange-500/80">Yazar: {webtoon.author}</p>
            </div>
            
            <div className="flex items-center gap-4 rounded-2xl bg-zinc-900/30 p-4 ring-1 ring-zinc-800/50 backdrop-blur-sm">
              <span className="text-xs font-black text-zinc-500 uppercase tracking-widest">Puan Ver:</span>
              <div className="flex gap-1.5">
                {[1, 2, 3, 4, 5].map(star => (
                  <button 
                    key={star} 
                    onClick={() => user ? handleRate(star) : (window as any).showAuthModal?.()}
                    className="transition-all hover:scale-125 active:scale-90"
                  >
                    <Star className={cn(
                      "h-6 w-6",
                      (userRating || 0) >= star ? "fill-orange-500 text-orange-500" : "text-zinc-800"
                    )} />
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {webtoon.genres?.map(genre => (
                <span key={genre} className="rounded-xl bg-zinc-900/50 px-4 py-2 text-[11px] font-black text-zinc-400 border border-zinc-800/50 uppercase tracking-widest hover:border-orange-500/30 transition-colors cursor-default">
                  {genre}
                </span>
              ))}
            </div>

            <div className="max-w-3xl text-lg font-medium text-zinc-400 leading-relaxed">
              {webtoon.description}
            </div>
          </div>
        </div>

        <div className="mt-20 grid grid-cols-1 gap-12 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <h2 className="mb-6 flex items-center gap-2 text-xl font-bold text-white">
            <Clock className="h-5 w-5 text-orange-500" />
            Bölümler
          </h2>
          <div className="flex flex-col gap-2">
            {visibleChapters.map((chapter) => (
              <Link 
                key={chapter.id} 
                to={`/webtoon/${id}/chapter/${chapter.id}`}
                className={cn(
                  "flex items-center justify-between rounded-lg border border-zinc-900 bg-zinc-900/50 p-4 transition-colors hover:border-orange-500/50 hover:bg-zinc-900",
                  chapter.publishAt?.toDate() > new Date() && "opacity-50 border-dashed"
                )}
              >
                <div className="flex items-center gap-4">
                  <span className="flex h-10 w-10 items-center justify-center rounded bg-zinc-800 text-sm font-bold text-zinc-400">
                    {chapter.number}
                  </span>
                  <div className="flex flex-col">
                    <span className="font-semibold text-zinc-200">{chapter.title}</span>
                    {chapter.publishAt?.toDate() > new Date() && (
                      <span className="text-[10px] font-bold text-orange-500 uppercase">Planlandı: {format(chapter.publishAt.toDate(), 'dd.MM HH:mm')}</span>
                    )}
                  </div>
                </div>
                <ChevronRight className="h-5 w-5 text-zinc-600" />
              </Link>
            ))}
            {visibleChapters.length === 0 && <p className="text-zinc-500">Henüz yayınlanmış bölüm bulunamadı.</p>}
          </div>
        </div>

        <div>
          <CommentsSection targetId={id} user={user} />
        </div>
      </div>
    </div>
  </div>
  );
};

const CommentsSection = ({ targetId, user }: { targetId: string, user: User | null }) => {
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const q = query(collection(db, 'comments'), where('targetId', '==', targetId), orderBy('createdAt', 'desc'));
    getDocs(q).then((snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Comment));
      setComments(data);
    }).catch((error) => {
      handleFirestoreError(error, OperationType.LIST, 'comments');
    });
    return () => {};
  }, [targetId]);

  const fetchComments = async () => {
    const q = query(collection(db, 'comments'), where('targetId', '==', targetId), orderBy('createdAt', 'desc'));
    const snapshot = await getDocs(q);
    setComments(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Comment)));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newComment.trim()) return;

    setSubmitting(true);
    try {
      await addDoc(collection(db, 'comments'), {
        targetId,
        userId: user.uid,
        userName: user.displayName,
        userPhoto: user.photoURL,
        text: newComment,
        createdAt: serverTimestamp()
      });
      setNewComment('');
      fetchComments();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'comments');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col gap-6">
      <h2 className="flex items-center gap-2 text-xl font-bold text-white">
        <MessageSquare className="h-5 w-5 text-orange-500" />
        Yorumlar ({comments.length})
      </h2>

      {user ? (
        <form onSubmit={handleSubmit} className="flex flex-col gap-3">
          <textarea 
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder="Düşüncelerini paylaş..."
            className="min-h-[100px] w-full rounded-lg border border-zinc-800 bg-zinc-900 p-3 text-sm text-white focus:border-orange-500 focus:outline-none"
          />
          <button 
            disabled={submitting || !newComment.trim()}
            className="self-end rounded-lg bg-orange-600 px-6 py-2 text-sm font-bold text-white transition-colors hover:bg-orange-500 disabled:opacity-50"
          >
            {submitting ? 'Gönderiliyor...' : 'Yorum Yap'}
          </button>
        </form>
      ) : (
        <div className="rounded-lg border border-dashed border-zinc-800 p-6 text-center text-zinc-500">
          Yorum yapmak için giriş yapmalısın.
        </div>
      )}

      <div className="flex flex-col gap-4">
        {comments.map((comment) => (
          <div key={comment.id} className="flex gap-3 rounded-lg bg-zinc-900/30 p-4 ring-1 ring-zinc-900">
            <img src={comment.userPhoto || undefined} alt={comment.userName || ''} className="h-10 w-10 rounded-full" referrerPolicy="no-referrer" />
            <div className="flex flex-col gap-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-white">{comment.userName}</span>
                <span className="text-[10px] text-zinc-500">
                  {comment.createdAt?.toDate ? format(comment.createdAt.toDate(), 'dd.MM.yyyy HH:mm') : 'Az önce'}
                </span>
              </div>
              <p className="text-sm text-zinc-400">{comment.text}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const ReaderImage = ({ url, index }: { url: string, index: number }) => {
  const [status, setStatus] = useState<'loading' | 'success' | 'error' | 'proxying'>('loading');
  const [retryCount, setRetryCount] = useState(0);
  const cleanUrl = url.trim();

  const getSource = () => {
    if (status === 'proxying') {
      return `/api/proxy-image?url=${encodeURIComponent(cleanUrl)}&retry=${retryCount}`;
    }
    return cleanUrl;
  };

  const handleError = () => {
    if (status === 'loading') {
      setStatus('proxying');
    } else {
      setStatus('error');
    }
  };

  const handleRetry = (e: React.MouseEvent) => {
    e.stopPropagation();
    setRetryCount(prev => prev + 1);
    setStatus('loading');
  };

  return (
    <div className={cn(
      "relative w-full overflow-hidden transition-all duration-500",
      status === 'loading' ? "min-h-[400px] bg-zinc-900/20 animate-pulse" : "",
      status === 'error' ? "min-h-[300px] bg-red-500/5" : ""
    )}>
      {status === 'loading' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
          <Loader2 className="h-8 w-8 animate-spin text-orange-500/50" />
          <span className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest">Sayfa {index + 1} Yükleniyor...</span>
        </div>
      )}

      {status === 'proxying' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-orange-500/5">
          <RefreshCw className="h-8 w-8 animate-spin text-orange-500/40" />
          <div className="text-center">
            <p className="text-[10px] font-black text-orange-500 uppercase tracking-widest">Yedek Sunucu Deneniyor</p>
            <p className="text-[9px] text-zinc-500">Doğrudan bağlantı başarısız oldu...</p>
          </div>
        </div>
      )}

      {status === 'error' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 p-6 text-center">
          <div className="rounded-full bg-red-500/10 p-4 ring-1 ring-red-500/20">
            <AlertTriangle className="h-8 w-8 text-red-500" />
          </div>
          <div className="space-y-1">
            <h4 className="text-sm font-bold text-white">Resim Yüklenemedi</h4>
            <p className="max-w-[200px] text-[10px] text-zinc-500">Bağlantı hatası veya geçersiz URL. Lütfen internetinizi kontrol edin.</p>
          </div>
          <button 
            onClick={handleRetry}
            className="flex items-center gap-2 rounded-xl bg-zinc-900 px-6 py-2.5 text-xs font-bold text-white hover:bg-zinc-800 transition-all active:scale-95"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Tekrar Dene
          </button>
        </div>
      )}

      <img 
        src={getSource()} 
        alt={`Sayfa ${index + 1}`} 
        className={cn(
          "w-full transition-opacity duration-700",
          status === 'success' ? "opacity-100" : "opacity-0 absolute inset-0"
        )}
        referrerPolicy="no-referrer"
        loading={index < 3 ? "eager" : "lazy"}
        decoding="async"
        onLoad={() => setStatus('success')}
        onError={handleError}
      />
    </div>
  );
};

const ChapterReader = ({ user, profile }: { user: User | null, profile: UserProfile | null }) => {
  const { id, chapterId } = useParams();
  const navigate = useNavigate();
  const [chapter, setChapter] = useState<Chapter | null>(null);
  const [webtoon, setWebtoon] = useState<Webtoon | null>(null);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [loading, setLoading] = useState(true);
  const [isLiked, setIsLiked] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showHeader, setShowHeader] = useState(true);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [lastScrollY, setLastScrollY] = useState(0);
  const [settings, setSettings] = useState({
    fontSize: profile?.settings?.fontSize || 18,
    fontFamily: profile?.settings?.fontFamily || 'font-sans',
    theme: profile?.settings?.theme || 'dark'
  });

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      const windowHeight = document.documentElement.scrollHeight - window.innerHeight;
      const progress = (currentScrollY / windowHeight) * 100;
      setScrollProgress(progress);

      if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setShowHeader(false);
      } else {
        setShowHeader(true);
      }
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  useEffect(() => {
    if (!id || !chapterId) return;

    // Fetch Webtoon info for SEO
    const webtoonRef = doc(db, 'webtoons', id);
    getDoc(webtoonRef).then((snapshot) => {
      if (snapshot.exists()) {
        setWebtoon({ id: snapshot.id, ...snapshot.data() } as Webtoon);
      }
    }).catch(err => {
      setLoading(false);
      handleFirestoreError(err, OperationType.GET, 'webtoons');
    });

    const docRef = doc(db, `webtoons/${id}/chapters`, chapterId);
    getDoc(docRef).then((snapshot) => {
      if (snapshot.exists()) {
        const data = { id: snapshot.id, ...snapshot.data() } as Chapter;
        setChapter(data);
        setLoading(false);
        
        // Track progress
        if (user) {
          setDoc(doc(db, 'progress', `${user.uid}_${id}`), {
            userId: user.uid,
            webtoonId: id,
            chapterId: chapterId,
            chapterNumber: data.number,
            updatedAt: serverTimestamp()
          }, { merge: true }).catch(() => {});
        }
      }
    }).catch(err => {
      setLoading(false);
      handleFirestoreError(err, OperationType.GET, `webtoons/${id}/chapters/${chapterId}`);
    });

    const chaptersQ = query(collection(db, `webtoons/${id}/chapters`), orderBy('number', 'asc'));
    getDocs(chaptersQ).then((snapshot) => {
      setChapters(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Chapter)));
    }).catch(err => {
      setLoading(false);
      handleFirestoreError(err, OperationType.LIST, 'chapters');
    });

    return () => {};
  }, [id, chapterId, user]);

  useEffect(() => {
    if (!user || !chapterId) return;
    const likeQ = query(collection(db, 'chapterLikes'), where('userId', '==', user.uid), where('chapterId', '==', chapterId));
    getDocs(likeQ).then((snapshot) => {
      setIsLiked(!snapshot.empty);
    }).catch(err => console.error('Like check error:', err));
    return () => {};
  }, [user, chapterId]);

  const toggleLike = async () => {
    if (!user || !chapterId || !id) return;
    try {
      const likeRef = doc(db, 'chapterLikes', `${user.uid}_${chapterId}`);
      const chapterRef = doc(db, `webtoons/${id}/chapters`, chapterId);
      
      if (isLiked) {
        await deleteDoc(likeRef);
        await updateDoc(chapterRef, { likeCount: increment(-1) });
      } else {
        await setDoc(likeRef, {
          userId: user.uid,
          chapterId: chapterId,
          createdAt: serverTimestamp()
        });
        await updateDoc(chapterRef, { likeCount: increment(1) });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'chapterLikes');
    }
  };

  const updateSettings = async (newSettings: any) => {
    const updated = { ...settings, ...newSettings };
    setSettings(updated);
    if (user) {
      try {
        await updateDoc(doc(db, 'users', user.uid), { settings: updated });
      } catch (error) {}
    }
  };

  const isAdmin = profile?.role === 'admin';
  const visibleChapters = chapters.filter(ch => {
    if (isAdmin) return true;
    if (!ch.publishAt) return true;
    return ch.publishAt.toDate() <= new Date();
  });

  const currentIdx = visibleChapters.findIndex(c => c.id === chapterId);
  const prevChapter = currentIdx > 0 ? visibleChapters[currentIdx - 1] : null;
  const nextChapter = currentIdx < visibleChapters.length - 1 ? visibleChapters[currentIdx + 1] : null;

  if (loading) return <div className="flex h-screen items-center justify-center bg-black text-zinc-500">Yükleniyor...</div>;
  if (!chapter) return <div className="flex h-screen items-center justify-center bg-black text-zinc-500">Bölüm bulunamadı.</div>;

  const isScheduled = chapter.publishAt && chapter.publishAt.toDate() > new Date();
  if (isScheduled && !isAdmin) {
    return (
      <div className="flex h-screen flex-col items-center justify-center bg-black px-4 text-center">
        <Clock className="mb-4 h-12 w-12 text-orange-500" />
        <h1 className="text-2xl font-black text-white font-display">Bu Bölüm Henüz Yayınlanmadı</h1>
        <p className="mt-2 text-zinc-500">Bu bölüm {format(chapter.publishAt.toDate(), 'dd MMMM yyyy HH:mm')} tarihinde yayınlanacak.</p>
        <Link to={`/webtoon/${id}`} className="mt-8 rounded-xl bg-zinc-900 px-8 py-3 text-sm font-bold text-white hover:bg-zinc-800">
          Geri Dön
        </Link>
      </div>
    );
  }

  const themeClasses = {
    dark: 'bg-zinc-950 text-zinc-300',
    light: 'bg-white text-zinc-900',
    sepia: 'bg-[#f4ecd8] text-[#5b4636]'
  };

  return (
    <div className={cn("min-h-screen transition-colors duration-300", themeClasses[settings.theme as keyof typeof themeClasses])}>
      <Helmet>
        <title>{`Bölüm ${chapter.number}: ${chapter.title} - ${webtoon?.title || 'WebtoonZ'}`}</title>
      </Helmet>
      
      <AnimatePresence>
        {showHeader && (
          <motion.div 
            initial={{ y: -100 }}
            animate={{ y: 0 }}
            exit={{ y: -100 }}
            transition={{ type: 'spring', damping: 20, stiffness: 100 }}
            className="sticky top-0 z-50 flex flex-col border-b border-zinc-800/50 bg-black/90 backdrop-blur-xl"
          >
            <div className="flex items-center justify-between px-4 py-3">
              <Link to={`/webtoon/${id}`} className="flex items-center gap-1 text-sm font-bold text-zinc-400 hover:text-white">
                <ChevronLeft className="h-5 w-5" />
                <span className="hidden sm:inline">Geri Dön</span>
              </Link>
              <div className="flex flex-col items-center max-w-[50%]">
                <h1 className="text-xs font-black text-white line-clamp-1 uppercase tracking-tighter opacity-50">{webtoon?.title}</h1>
                <p className="text-sm font-bold text-white line-clamp-1">Bölüm {chapter.number}: {chapter.title}</p>
              </div>
              <div className="flex items-center gap-2">
                {!chapter.images && (
                  <button 
                    onClick={() => setShowSettings(!showSettings)}
                    className="rounded-lg p-2 text-zinc-400 hover:bg-zinc-800 hover:text-white"
                  >
                    <Settings className="h-5 w-5" />
                  </button>
                )}
                <button 
                  onClick={() => user ? toggleLike() : (window as any).showAuthModal?.()}
                  className={cn(
                    "flex items-center gap-1 rounded-full px-3 py-1 text-xs font-bold transition-all",
                    isLiked ? "bg-orange-500 text-white" : "bg-zinc-800 text-zinc-400 hover:text-white"
                  )}
                >
                  <ThumbsUp className={cn("h-3 w-3", isLiked && "fill-white")} />
                  {chapter.likeCount || 0}
                </button>
                <button 
                  onClick={() => alert('Hatalı resim bildirimi alındı. En kısa sürede kontrol edilecektir.')}
                  className="rounded-lg p-2 text-zinc-400 hover:bg-zinc-800 hover:text-red-500 transition-colors"
                  title="Hatalı Resim Bildir"
                >
                  <Flag className="h-4 w-4" />
                </button>
              </div>
            </div>
            {/* Scroll Progress Bar */}
            <div className="h-[2px] w-full bg-zinc-900">
              <motion.div 
                className="h-full bg-orange-500" 
                style={{ width: `${scrollProgress}%` }}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Reader Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl border border-zinc-800 bg-zinc-900 p-6 shadow-2xl">
            <h2 className="mb-4 text-lg font-bold text-white">Okuyucu Ayarları</h2>
            <div className="space-y-6">
              <div>
                <label className="mb-2 block text-xs font-bold text-zinc-500 uppercase">Yazı Boyutu</label>
                <div className="flex items-center gap-4">
                  <input 
                    type="range" min="12" max="32" 
                    value={settings.fontSize} 
                    onChange={e => updateSettings({ fontSize: parseInt(e.target.value) })}
                    className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-zinc-800 accent-orange-500"
                  />
                  <span className="text-sm font-bold text-white">{settings.fontSize}px</span>
                </div>
              </div>
              <div>
                <label className="mb-2 block text-xs font-bold text-zinc-500 uppercase">Tema</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['dark', 'light', 'sepia'] as const).map(t => (
                    <button 
                      key={t}
                      onClick={() => updateSettings({ theme: t })}
                      className={cn(
                        "rounded-lg py-2 text-xs font-bold capitalize transition-all border",
                        settings.theme === t ? "border-orange-500 bg-orange-500/10 text-orange-500" : "border-zinc-800 bg-zinc-950 text-zinc-500"
                      )}
                    >
                      {t === 'dark' ? 'Koyu' : t === 'light' ? 'Açık' : 'Sepya'}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <button 
              onClick={() => setShowSettings(false)}
              className="mt-8 w-full rounded-xl bg-orange-600 py-3 text-sm font-bold text-white hover:bg-orange-500"
            >
              Kapat
            </button>
          </div>
        </div>
      )}

      <div 
        className="mx-auto max-w-4xl"
        onClick={() => setShowHeader(!showHeader)}
      >
        {chapter.images ? (
          <div className="flex flex-col">
            {chapter.images.map((url, idx) => (
              <ReaderImage key={`${idx}-${url}`} url={url} index={idx} />
            ))}
          </div>
        ) : (
          <div 
            className="mx-auto px-6 py-12"
            style={{ 
              fontSize: `${settings.fontSize}px`,
              fontFamily: settings.fontFamily === 'font-serif' ? 'serif' : 'sans-serif',
              lineHeight: '1.8'
            }}
          >
            <ReactMarkdown>{chapter.content || ''}</ReactMarkdown>
          </div>
        )}
      </div>

      {/* Floating Navigation Controls */}
      <AnimatePresence>
        {!showHeader && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-8 left-1/2 z-50 flex -translate-x-1/2 items-center gap-2 rounded-full bg-black/80 p-1.5 backdrop-blur-xl ring-1 ring-zinc-800 shadow-2xl"
          >
            <button 
              disabled={!prevChapter}
              onClick={(e) => {
                e.stopPropagation();
                if (prevChapter) navigate(`/webtoon/${id}/chapter/${prevChapter.id}`);
              }}
              className="flex h-12 w-12 items-center justify-center rounded-full bg-zinc-900 text-white disabled:opacity-30 hover:bg-zinc-800 transition-colors"
            >
              <ChevronLeft className="h-6 w-6" />
            </button>
            <div className="px-4 text-xs font-black text-white uppercase tracking-widest">
              {Math.round(scrollProgress)}%
            </div>
            <button 
              disabled={!nextChapter}
              onClick={(e) => {
                e.stopPropagation();
                if (nextChapter) navigate(`/webtoon/${id}/chapter/${nextChapter.id}`);
              }}
              className="flex h-12 w-12 items-center justify-center rounded-full bg-orange-600 text-white disabled:opacity-30 hover:bg-orange-500 transition-colors"
            >
              <ChevronRight className="h-6 w-6" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Bottom Navigation */}
      <div className="flex flex-col items-center gap-8 border-t border-zinc-800/50 bg-black/40 py-16 px-4">
        <div className="flex w-full max-w-md items-center justify-between gap-4">
          {prevChapter ? (
            <Link to={`/webtoon/${id}/chapter/${prevChapter.id}`} className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-zinc-900 py-4 text-sm font-bold text-white transition-all hover:bg-zinc-800">
              <ChevronLeft className="h-4 w-4" />
              Önceki
            </Link>
          ) : <div className="flex-1" />}
          
          <Link to={`/webtoon/${id}`} className="flex h-14 w-14 items-center justify-center rounded-2xl bg-zinc-900 text-white transition-all hover:bg-zinc-800">
            <Layout className="h-6 w-6" />
          </Link>

          {nextChapter ? (
            <Link to={`/webtoon/${id}/chapter/${nextChapter.id}`} className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-orange-600 py-4 text-sm font-bold text-white transition-all hover:bg-orange-500 shadow-lg shadow-orange-600/20">
              Sonraki
              <ChevronRight className="h-4 w-4" />
            </Link>
          ) : <div className="flex-1" />}
        </div>

        <div className="flex flex-col items-center gap-2 text-center">
          <p className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Bölüm Sonu</p>
          <h3 className="text-lg font-bold text-white">{chapter.title}</h3>
        </div>
      </div>

      {/* Floating Progress Indicator (Mobile) */}
      <div className="fixed bottom-6 right-6 z-40 sm:hidden">
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-black/80 text-[10px] font-black text-white backdrop-blur-md ring-1 ring-zinc-800">
          {Math.round((currentIdx + 1) / visibleChapters.length * 100)}%
        </div>
      </div>
    </div>
  );
};

const ProfilePage = ({ user, profile }: { user: User | null, profile: UserProfile | null }) => {
  const [favorites, setFavorites] = useState<Favorite[]>([]);
  const [progress, setProgress] = useState<Progress[]>([]);
  const [webtoons, setWebtoons] = useState<Webtoon[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState<'profile' | 'account'>('profile');
  const [editData, setEditData] = useState({
    displayName: profile?.displayName || '',
    photoURL: profile?.photoURL || '',
    bio: profile?.bio || '',
    bannerURL: profile?.bannerURL || ''
  });
  const [accountData, setAccountData] = useState({
    email: user?.email || '',
    newPassword: ''
  });
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    if (profile) {
      setEditData({
        displayName: profile.displayName,
        photoURL: profile.photoURL,
        bio: profile.bio || '',
        bannerURL: profile.bannerURL || ''
      });
    }
  }, [profile]);

  useEffect(() => {
    if (user) {
      setAccountData(prev => ({ ...prev, email: user.email || '' }));
    }
  }, [user]);

  useEffect(() => {
    if (!user) return;
    const webtoonsQ = query(collection(db, 'webtoons'), limit(50));
    getDocs(webtoonsQ).then((snapshot) => {
      setWebtoons(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Webtoon)));
    }).catch(err => handleFirestoreError(err, OperationType.LIST, 'webtoons'));

    const favsQ = query(collection(db, 'favorites'), where('userId', '==', user.uid), limit(50));
    getDocs(favsQ).then((snapshot) => {
      setFavorites(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Favorite)));
    }).catch(err => handleFirestoreError(err, OperationType.LIST, 'favorites'));

    const progressQ = query(collection(db, 'progress'), where('userId', '==', user.uid), orderBy('updatedAt', 'desc'), limit(50));
    getDocs(progressQ).then((snapshot) => {
      setProgress(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Progress)));
    }).catch(err => handleFirestoreError(err, OperationType.LIST, 'progress'));

    return () => {};
  }, [user]);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setUpdating(true);
    try {
      const isBase64 = editData.photoURL.startsWith('data:');
      
      if (!isBase64) {
        await updateProfile(user, {
          displayName: editData.displayName,
          photoURL: editData.photoURL
        });
      } else {
        await updateProfile(user, {
          displayName: editData.displayName
        });
      }

      await updateDoc(doc(db, 'users', user.uid), {
        displayName: editData.displayName,
        photoURL: editData.photoURL,
        bio: editData.bio,
        bannerURL: editData.bannerURL
      });

      setIsEditing(false);
      setUpdating(false);
      alert('Profil başarıyla güncellendi.');
    } catch (error: any) {
      setUpdating(false);
      console.error("Profile Update Error:", error);
      alert('Profil güncellenirken bir hata oluştu: ' + (error.message || 'Bilinmeyen hata'));
    }
  };

  const handleUpdateAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setUpdating(true);
    try {
      if (accountData.email !== user.email) {
        await updateEmail(user, accountData.email);
        await updateDoc(doc(db, 'users', user.uid), { email: accountData.email });
      }
      if (accountData.newPassword) {
        await updatePassword(user, accountData.newPassword);
      }
      alert('Hesap bilgileri başarıyla güncellendi.');
      setAccountData(prev => ({ ...prev, newPassword: '' }));
    } catch (error: any) {
      console.error("Account Update Error:", error);
      alert('Hesap güncellenirken bir hata oluştu. Güvenlik nedeniyle bu işlem için yakın zamanda giriş yapmış olmanız gerekebilir.');
    } finally {
      setUpdating(false);
    }
  };

  if (!user) return <div className="flex h-screen items-center justify-center text-zinc-500">Lütfen giriş yapın.</div>;

  return (
    <div className="container mx-auto px-4 py-12">
      <Helmet>
        <title>{`${profile?.displayName || user.displayName} - Profil - WebtoonZ`}</title>
      </Helmet>
      {/* Banner Section */}
      <div className="relative mb-20">
        <div className="h-48 w-full overflow-hidden rounded-3xl bg-zinc-900 md:h-64">
          {profile?.bannerURL ? (
            <img src={profile.bannerURL} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
          ) : (
            <div className="h-full w-full bg-gradient-to-br from-zinc-900 to-zinc-950" />
          )}
        </div>
        
        <div className="absolute -bottom-16 left-1/2 -translate-x-1/2 md:left-12 md:translate-x-0">
          <div className="relative h-32 w-32 shrink-0 overflow-hidden rounded-3xl ring-8 ring-black">
            <img 
              src={profile?.photoURL || user.photoURL || undefined} 
              className="h-full w-full object-cover" 
              referrerPolicy="no-referrer" 
            />
          </div>
        </div>
      </div>

      <div className="mb-12 flex flex-col items-center gap-6 md:flex-row md:items-start md:pl-48">
        <div className="flex-1 text-center md:text-left">
          <div className="flex flex-col items-center gap-4 md:flex-row md:items-center">
            <h1 className="text-4xl font-black text-white font-display tracking-tight">{profile?.displayName || user.displayName}</h1>
            <button 
              onClick={() => setIsEditing(true)}
              className="flex items-center gap-2 rounded-xl bg-zinc-900 px-4 py-2 text-xs font-bold text-zinc-400 transition-all hover:bg-zinc-800 hover:text-white"
            >
              <Edit className="h-3 w-3" />
              Profili Düzenle
            </button>
          </div>
          {profile?.bio && <p className="mt-2 max-w-2xl text-zinc-400">{profile.bio}</p>}
          <div className="mt-4 flex flex-wrap justify-center gap-3 md:justify-start">
            <div className="rounded-xl bg-zinc-900 px-4 py-2">
              <p className="text-[10px] font-black uppercase text-zinc-500 tracking-widest">Okunan Bölüm</p>
              <p className="text-lg font-black text-white">{progress.length}</p>
            </div>
            <div className="rounded-xl bg-zinc-900 px-4 py-2">
              <p className="text-[10px] font-black uppercase text-zinc-500 tracking-widest">Favoriler</p>
              <p className="text-lg font-black text-white">{favorites.length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Edit Modal / Overlay */}
      {isEditing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          <div className="w-full max-w-2xl overflow-hidden rounded-3xl bg-zinc-950 ring-1 ring-zinc-800">
            <div className="flex border-b border-zinc-900">
              <button 
                onClick={() => setActiveTab('profile')}
                className={cn(
                  "flex flex-1 items-center justify-center gap-2 py-4 text-sm font-bold transition-all",
                  activeTab === 'profile' ? "bg-zinc-900 text-white" : "text-zinc-500 hover:text-zinc-300"
                )}
              >
                <UserSettingsIcon className="h-4 w-4" />
                Profil Ayarları
              </button>
              <button 
                onClick={() => setActiveTab('account')}
                className={cn(
                  "flex flex-1 items-center justify-center gap-2 py-4 text-sm font-bold transition-all",
                  activeTab === 'account' ? "bg-zinc-900 text-white" : "text-zinc-500 hover:text-zinc-300"
                )}
              >
                <Lock className="h-4 w-4" />
                Hesap Ayarları
              </button>
            </div>

            <div className="max-h-[70vh] overflow-y-auto p-8">
              {activeTab === 'profile' ? (
                <form onSubmit={handleUpdateProfile} className="flex flex-col gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase text-zinc-500 tracking-widest">Görünen Ad</label>
                    <input 
                      required
                      className="w-full rounded-xl border border-zinc-800 bg-zinc-900 p-3 text-white focus:border-orange-500 focus:outline-none"
                      value={editData.displayName}
                      onChange={e => setEditData({...editData, displayName: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase text-zinc-500 tracking-widest">Hakkımda</label>
                    <textarea 
                      className="w-full rounded-xl border border-zinc-800 bg-zinc-900 p-3 text-white focus:border-orange-500 focus:outline-none"
                      rows={3}
                      value={editData.bio}
                      onChange={e => setEditData({...editData, bio: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase text-zinc-500 tracking-widest">Profil Resmi URL</label>
                    <input 
                      className="w-full rounded-xl border border-zinc-800 bg-zinc-900 p-3 text-white focus:border-orange-500 focus:outline-none"
                      value={editData.photoURL}
                      onChange={e => setEditData({...editData, photoURL: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase text-zinc-500 tracking-widest">Banner Resmi URL</label>
                    <input 
                      className="w-full rounded-xl border border-zinc-800 bg-zinc-900 p-3 text-white focus:border-orange-500 focus:outline-none"
                      value={editData.bannerURL}
                      onChange={e => setEditData({...editData, bannerURL: e.target.value})}
                    />
                  </div>
                  <div className="flex gap-3 pt-4">
                    <button 
                      type="submit"
                      disabled={updating}
                      className="flex-1 rounded-xl bg-orange-600 py-3 text-sm font-bold text-white hover:bg-orange-500 disabled:opacity-50"
                    >
                      {updating ? 'Güncelleniyor...' : 'Değişiklikleri Kaydet'}
                    </button>
                    <button 
                      type="button"
                      onClick={() => setIsEditing(false)}
                      className="rounded-xl bg-zinc-800 px-8 py-3 text-sm font-bold text-zinc-400 hover:bg-zinc-700"
                    >
                      Kapat
                    </button>
                  </div>
                </form>
              ) : (
                <form onSubmit={handleUpdateAccount} className="flex flex-col gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase text-zinc-500 tracking-widest">E-posta Adresi</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
                      <input 
                        type="email"
                        required
                        className="w-full rounded-xl border border-zinc-800 bg-zinc-900 p-3 pl-10 text-white focus:border-orange-500 focus:outline-none"
                        value={accountData.email}
                        onChange={e => setAccountData({...accountData, email: e.target.value})}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase text-zinc-500 tracking-widest">Yeni Şifre (Boş bırakılabilir)</label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
                      <input 
                        type="password"
                        className="w-full rounded-xl border border-zinc-800 bg-zinc-900 p-3 pl-10 text-white focus:border-orange-500 focus:outline-none"
                        placeholder="••••••••"
                        value={accountData.newPassword}
                        onChange={e => setAccountData({...accountData, newPassword: e.target.value})}
                      />
                    </div>
                    <p className="text-[10px] text-zinc-500">Şifrenizi değiştirmek istemiyorsanız boş bırakın.</p>
                  </div>
                  <div className="flex gap-3 pt-4">
                    <button 
                      type="submit"
                      disabled={updating}
                      className="flex-1 rounded-xl bg-orange-600 py-3 text-sm font-bold text-white hover:bg-orange-500 disabled:opacity-50"
                    >
                      {updating ? 'Güncelleniyor...' : 'Hesabı Güncelle'}
                    </button>
                    <button 
                      type="button"
                      onClick={() => setIsEditing(false)}
                      className="rounded-xl bg-zinc-800 px-8 py-3 text-sm font-bold text-zinc-400 hover:bg-zinc-700"
                    >
                      Kapat
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-12 lg:grid-cols-2">
        <div>
          <h2 className="mb-6 flex items-center gap-2 text-xl font-bold text-white font-display">
            <Bookmark className="h-5 w-5 text-orange-500" />
            Favorilerim
          </h2>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
            {webtoons.filter(w => favorites.some(f => f.webtoonId === w.id)).map(item => (
              <Link key={item.id} to={`/webtoon/${item.id}`} className="group flex flex-col gap-2">
                <div className="relative aspect-[3/4] overflow-hidden rounded-2xl ring-1 ring-zinc-900 transition-all group-hover:ring-orange-500/50">
                  <img src={item.coverUrl || undefined} className="h-full w-full object-cover transition-transform group-hover:scale-110" referrerPolicy="no-referrer" />
                </div>
                <h3 className="text-xs font-bold text-white line-clamp-1 group-hover:text-orange-500">{item.title}</h3>
              </Link>
            ))}
          </div>
        </div>

        <div>
          <h2 className="mb-6 flex items-center gap-2 text-xl font-bold text-white font-display">
            <History className="h-5 w-5 text-orange-500" />
            Okuma Geçmişi
          </h2>
          <div className="space-y-3">
            {progress.map(prog => {
              const item = webtoons.find(w => w.id === prog.webtoonId);
              if (!item) return null;
              return (
                <Link key={prog.id} to={`/webtoon/${item.id}/chapter/${prog.chapterId}`} className="flex items-center gap-4 rounded-2xl border border-zinc-900 bg-zinc-900/30 p-4 transition-all hover:bg-zinc-900/50">
                  <img src={item.coverUrl || undefined} className="h-16 w-12 rounded-lg object-cover" referrerPolicy="no-referrer" />
                  <div className="flex flex-col">
                    <span className="text-sm font-bold text-white line-clamp-1">{item.title}</span>
                    <span className="text-xs text-zinc-500">Bölüm {prog.chapterNumber} • {format(prog.updatedAt?.toDate?.() || new Date(), 'dd.MM.yyyy')}</span>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

const AdminPanel = ({ profile }: { profile: UserProfile | null }) => {
  const [activeTab, setActiveTab] = useState<'content' | 'users'>('content');
  const [webtoons, setWebtoons] = useState<Webtoon[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [userSearch, setUserSearch] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [newWebtoon, setNewWebtoon] = useState({ 
    title: '', 
    description: '', 
    coverUrl: '', 
    author: '', 
    type: 'webtoon' as const,
    genres: [] as string[],
    scheduleDay: 'None',
    status: 'ongoing' as const
  });

  useEffect(() => {
    if (activeTab === 'content') {
      const q = query(collection(db, 'webtoons'), orderBy('createdAt', 'desc'));
      getDocs(q).then((snapshot) => {
        setWebtoons(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Webtoon)));
      }).catch(err => handleFirestoreError(err, OperationType.LIST, 'webtoons'));
    } else {
      const q = query(collection(db, 'users'), limit(50));
      getDocs(q).then((snapshot) => {
        setUsers(snapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() } as UserProfile)));
      }).catch(err => handleFirestoreError(err, OperationType.LIST, 'users'));
    }
  }, [activeTab]);

  if (profile?.role !== 'admin') {
    return <div className="flex h-64 items-center justify-center text-red-500">Yetkiniz yok.</div>;
  }

  const handleUpdateRole = async (userId: string, newRole: 'admin' | 'user') => {
    if (userId === profile.uid) {
      alert("Kendi yetkinizi değiştiremezsiniz.");
      return;
    }
    try {
      await updateDoc(doc(db, 'users', userId), { role: newRole });
      setUsers(prev => prev.map(u => u.uid === userId ? { ...u, role: newRole } : u));
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${userId}`);
    }
  };

  const filteredUsers = users.filter(u => 
    u.email?.toLowerCase().includes(userSearch.toLowerCase()) || 
    u.displayName?.toLowerCase().includes(userSearch.toLowerCase())
  );

  const handleAddWebtoon = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'webtoons'), {
        ...newWebtoon,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      setShowAdd(false);
      setNewWebtoon({ title: '', description: '', coverUrl: '', author: '', type: 'webtoon', genres: [], scheduleDay: 'None', status: 'ongoing' });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'webtoons');
    }
  };

  const toggleGenre = (genre: string) => {
    setNewWebtoon(prev => ({
      ...prev,
      genres: prev.genres.includes(genre) 
        ? prev.genres.filter(g => g !== genre)
        : [...prev.genres, genre]
    }));
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <Helmet>
        <title>Yönetici Paneli - WebtoonZ</title>
      </Helmet>
      <div className="mb-8 flex items-center justify-between">
        <h1 className="text-3xl font-black text-white font-display tracking-tight">Admin Paneli</h1>
        <div className="flex items-center gap-2">
          <div className="flex rounded-xl bg-zinc-900 p-1">
            <button 
              onClick={() => setActiveTab('content')}
              className={cn(
                "flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-bold transition-all",
                activeTab === 'content' ? "bg-zinc-800 text-white" : "text-zinc-500 hover:text-zinc-300"
              )}
            >
              <Layout className="h-3.5 w-3.5" />
              İçerikler
            </button>
            <button 
              onClick={() => setActiveTab('users')}
              className={cn(
                "flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-bold transition-all",
                activeTab === 'users' ? "bg-zinc-800 text-white" : "text-zinc-500 hover:text-zinc-300"
              )}
            >
              <Users className="h-3.5 w-3.5" />
              Kullanıcılar
            </button>
          </div>
          {activeTab === 'content' && (
            <button 
              onClick={() => setShowAdd(!showAdd)}
              className="flex items-center gap-2 rounded-xl bg-orange-600 px-6 py-3 text-sm font-bold text-white transition-all hover:bg-orange-500 shadow-lg shadow-orange-600/20"
            >
              <Plus className="h-4 w-4" />
              Yeni İçerik Ekle
            </button>
          )}
        </div>
      </div>

      {activeTab === 'content' ? (
        <>
          {/* Global Stats Summary */}
          <div className="mb-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
            <div className="rounded-2xl border border-zinc-900 bg-zinc-900/30 p-4">
              <p className="text-[10px] font-black uppercase text-zinc-500 tracking-widest">Toplam Seri</p>
              <p className="mt-1 text-2xl font-black text-white font-display">{webtoons.length}</p>
            </div>
            <div className="rounded-2xl border border-zinc-900 bg-zinc-900/30 p-4">
              <p className="text-[10px] font-black uppercase text-zinc-500 tracking-widest">Toplam İzlenme</p>
              <p className="mt-1 text-2xl font-black text-white font-display">
                {webtoons.reduce((acc, curr) => acc + (curr.viewCount || 0), 0)}
              </p>
            </div>
            <div className="rounded-2xl border border-zinc-900 bg-zinc-900/30 p-4">
              <p className="text-[10px] font-black uppercase text-zinc-500 tracking-widest">Webtoon</p>
              <p className="mt-1 text-2xl font-black text-white font-display">
                {webtoons.filter(w => w.type === 'webtoon').length}
              </p>
            </div>
            <div className="rounded-2xl border border-zinc-900 bg-zinc-900/30 p-4">
              <p className="text-[10px] font-black uppercase text-zinc-500 tracking-widest">Novel</p>
              <p className="mt-1 text-2xl font-black text-white font-display">
                {webtoons.filter(w => w.type === 'novel').length}
              </p>
            </div>
          </div>

          {showAdd && (
            <form onSubmit={handleAddWebtoon} className="mb-8 flex flex-col gap-4 rounded-xl border border-zinc-800 bg-zinc-900 p-6">
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <input 
                  required
                  placeholder="Başlık" 
                  className="rounded-lg border border-zinc-800 bg-zinc-950 p-3 text-white focus:border-orange-500 focus:outline-none"
                  value={newWebtoon.title}
                  onChange={e => setNewWebtoon({...newWebtoon, title: e.target.value})}
                />
                <input 
                  required
                  placeholder="Yazar" 
                  className="rounded-lg border border-zinc-800 bg-zinc-950 p-3 text-white focus:border-orange-500 focus:outline-none"
                  value={newWebtoon.author}
                  onChange={e => setNewWebtoon({...newWebtoon, author: e.target.value})}
                />
                <input 
                  required
                  placeholder="Kapak Resmi URL" 
                  className="rounded-lg border border-zinc-800 bg-zinc-950 p-3 text-white focus:border-orange-500 focus:outline-none"
                  value={newWebtoon.coverUrl}
                  onChange={e => setNewWebtoon({...newWebtoon, coverUrl: e.target.value})}
                />
                <select 
                  className="rounded-lg border border-zinc-800 bg-zinc-950 p-3 text-white focus:border-orange-500 focus:outline-none"
                  value={newWebtoon.type}
                  onChange={e => setNewWebtoon({...newWebtoon, type: e.target.value as any})}
                >
                  <option value="webtoon">Webtoon</option>
                  <option value="novel">Novel</option>
                </select>
                <select 
                  className="rounded-lg border border-zinc-800 bg-zinc-950 p-3 text-white focus:border-orange-500 focus:outline-none"
                  value={newWebtoon.scheduleDay}
                  onChange={e => setNewWebtoon({...newWebtoon, scheduleDay: e.target.value as any})}
                >
                  <option value="None">Yayın Günü Yok</option>
                  {DAYS.map(day => (
                    <option key={day.id} value={day.id}>{day.label}</option>
                  ))}
                </select>
                <select 
                  className="rounded-lg border border-zinc-800 bg-zinc-950 p-3 text-white focus:border-orange-500 focus:outline-none"
                  value={newWebtoon.status}
                  onChange={e => setNewWebtoon({...newWebtoon, status: e.target.value as any})}
                >
                  <option value="ongoing">Devam Ediyor</option>
                  <option value="completed">Tamamlandı</option>
                  <option value="hiatus">Ara Verildi</option>
                </select>
              </div>
              <textarea 
                required
                placeholder="Açıklama" 
                className="min-h-[100px] rounded-lg border border-zinc-800 bg-zinc-950 p-3 text-white focus:border-orange-500 focus:outline-none"
                value={newWebtoon.description}
                onChange={e => setNewWebtoon({...newWebtoon, description: e.target.value})}
              />

              <div className="flex flex-col gap-2">
                <label className="text-sm font-medium text-zinc-400">Kategoriler</label>
                <div className="flex flex-wrap gap-2">
                  {GENRES.map(genre => (
                    <button
                      key={genre}
                      type="button"
                      onClick={() => toggleGenre(genre)}
                      className={cn(
                        "rounded-full px-3 py-1 text-xs font-medium transition-colors",
                        newWebtoon.genres.includes(genre)
                          ? "bg-orange-600 text-white"
                          : "bg-zinc-950 text-zinc-500 border border-zinc-800 hover:border-zinc-700"
                      )}
                    >
                      {genre}
                    </button>
                  ))}
                </div>
              </div>

              <button className="rounded-lg bg-orange-600 py-3 font-bold text-white hover:bg-orange-500">Oluştur</button>
            </form>
          )}

          <div className="grid grid-cols-1 gap-3">
            {webtoons.map(item => (
              <div key={item.id} className="flex items-center justify-between rounded-2xl border border-zinc-900 bg-zinc-900/30 p-4 transition-all hover:bg-zinc-900/50">
                <div className="flex items-center gap-4">
                  <div className="relative h-16 w-12 shrink-0 overflow-hidden rounded-lg ring-1 ring-zinc-800">
                    <img src={item.coverUrl || undefined} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                  </div>
                  <div className="flex flex-col">
                    <h3 className="font-bold text-white leading-tight">{item.title}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[10px] font-black uppercase text-orange-500 tracking-wider">{item.type}</span>
                      <span className="text-zinc-600">•</span>
                      <span className="text-[11px] font-medium text-zinc-500">{item.author}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Link to={`/admin/webtoon/${item.id}`} className="flex h-9 w-9 items-center justify-center rounded-xl bg-zinc-800 text-zinc-400 transition-all hover:bg-zinc-700 hover:text-white">
                    <Edit className="h-4 w-4" />
                  </Link>
                  <button 
                    onClick={async () => {
                      if (window.confirm('Bu içeriği silmek istediğinize emin misiniz?')) {
                        try {
                          await deleteDoc(doc(db, 'webtoons', item.id));
                        } catch (error) {
                          handleFirestoreError(error, OperationType.DELETE, `webtoons/${item.id}`);
                        }
                      }
                    }}
                    className="flex h-9 w-9 items-center justify-center rounded-xl bg-zinc-800 text-zinc-400 transition-all hover:bg-red-500/10 hover:text-red-500"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : (
        <div className="flex flex-col gap-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
            <input 
              placeholder="Kullanıcı ara (Email veya İsim)..." 
              className="w-full rounded-2xl border border-zinc-900 bg-zinc-900/30 py-4 pl-12 pr-4 text-white focus:border-orange-500 focus:outline-none"
              value={userSearch}
              onChange={e => setUserSearch(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-1 gap-3">
            {filteredUsers.map(u => (
              <div key={u.uid} className="flex items-center justify-between rounded-2xl border border-zinc-900 bg-zinc-900/30 p-4 transition-all hover:bg-zinc-900/50">
                <div className="flex items-center gap-4">
                  <img src={u.photoURL} className="h-12 w-12 rounded-full ring-2 ring-zinc-800" />
                  <div className="flex flex-col">
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-white">{u.displayName}</h3>
                      {u.role === 'admin' && (
                        <span className="flex items-center gap-1 rounded-full bg-orange-500/10 px-2 py-0.5 text-[10px] font-black uppercase text-orange-500">
                          <ShieldCheck className="h-3 w-3" />
                          Admin
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-zinc-500">{u.email}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {u.role === 'admin' ? (
                    <button 
                      onClick={() => handleUpdateRole(u.uid, 'user')}
                      className="flex items-center gap-2 rounded-xl bg-zinc-800 px-4 py-2 text-xs font-bold text-zinc-400 transition-all hover:bg-zinc-700 hover:text-white"
                    >
                      <Shield className="h-3.5 w-3.5" />
                      Yetkiyi Al
                    </button>
                  ) : (
                    <button 
                      onClick={() => handleUpdateRole(u.uid, 'admin')}
                      className="flex items-center gap-2 rounded-xl bg-orange-600/10 px-4 py-2 text-xs font-bold text-orange-500 transition-all hover:bg-orange-600 hover:text-white"
                    >
                      <ShieldCheck className="h-3.5 w-3.5" />
                      Admin Yap
                    </button>
                  )}
                </div>
              </div>
            ))}
            {filteredUsers.length === 0 && (
              <div className="flex h-32 items-center justify-center rounded-2xl border border-dashed border-zinc-800 text-zinc-500">
                Kullanıcı bulunamadı.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

const AdminWebtoonDetail = ({ profile }: { profile: UserProfile | null }) => {
  const { id } = useParams();
  const [webtoon, setWebtoon] = useState<Webtoon | null>(null);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [showAddChapter, setShowAddChapter] = useState(false);
  const [newChapter, setNewChapter] = useState({ title: '', number: 1, content: '', images: '', publishAt: '' });
  const [isGeneratingSummary, setIsGeneratingSummary] = useState(false);
  const [albumUrl, setAlbumUrl] = useState('');
  const [isFetchingAlbum, setIsFetchingAlbum] = useState(false);
  const [sourceHtml, setSourceHtml] = useState('');
  const [fetchMode, setFetchMode] = useState<'link' | 'source' | 'upload'>('link');
  const [isUploading, setIsUploading] = useState(false);
  const [imgbbKey, setImgbbKey] = useState("7016335964860d8299298f623098595b");
  const [uploadError, setUploadError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    const webtoonRef = doc(db, 'webtoons', id);
    getDoc(webtoonRef).then((snapshot) => {
      if (snapshot.exists()) setWebtoon({ id: snapshot.id, ...snapshot.data() } as Webtoon);
    }).catch(err => handleFirestoreError(err, OperationType.GET, `webtoons/${id}`));

    const chaptersQ = query(collection(db, `webtoons/${id}/chapters`), orderBy('number', 'asc'));
    getDocs(chaptersQ).then((snapshot) => {
      setChapters(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Chapter)));
    }).catch(err => handleFirestoreError(err, OperationType.LIST, `webtoons/${id}/chapters`));
    
    return () => {};
  }, [id]);

  const generateAISummary = async () => {
    if (!webtoon || !id) return;
    setIsGeneratingSummary(true);
    try {
      const prompt = `Aşağıdaki webtoon/novel başlığı ve mevcut açıklamasına dayanarak, okuyucuları cezbedecek, profesyonel ve etkileyici bir özet yaz. Sadece özeti döndür.
      Başlık: ${webtoon.title}
      Mevcut Açıklama: ${webtoon.description}`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
      });

      const summary = response.text;
      if (summary) {
        await updateDoc(doc(db, 'webtoons', id), { description: summary });
      }
    } catch (error) {
      console.error("AI Summary Error:", error);
    } finally {
      setIsGeneratingSummary(false);
    }
  };

  const fetchAlbumImages = async () => {
    if (!albumUrl.trim()) return;
    setIsFetchingAlbum(true);
    try {
      const response = await fetch('/api/fetch-images', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: albumUrl })
      });
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Sunucu hatası oluştu.');
      }

      if (data.images && data.images.length > 0) {
        setNewChapter(prev => ({
          ...prev,
          images: data.images.join('\n')
        }));
        setAlbumUrl('');
        alert(`${data.images.length} adet resim başarıyla çekildi!`);
      } else {
        alert('Bu linkten resim bulunamadı. Lütfen doğrudan resim linklerini kullanın veya linkin herkese açık olduğundan emin olun.');
      }
    } catch (error: any) {
      console.error("Fetch Album Error:", error);
      alert(error.message || 'Resimler çekilirken bir hata oluştu.');
    } finally {
      setIsFetchingAlbum(false);
    }
  };

  const extractFromSource = () => {
    if (!sourceHtml.trim()) return;
    // Optimized regex to catch internal uploads, common image formats, and dynamic image paths
    const imageRegex = /https?:\/\/[^"'\s]+(?:\.(?:jpg|jpeg|png|gif|webp|svg|avif)|(?:\/api\/images\/[^"'\s]+)|(?:googleusercontent\.com\/[^"'\s]+)|(?:\/uploads\/[^"'\s]+))(?:\?[^"'\s]*)?/gi;
    const matches = sourceHtml.match(imageRegex) || [];
    const uniqueImages = [...new Set(matches)].filter(img => 
      !img.includes("favicon") && 
      !img.includes("logo") &&
      !img.includes("avatar") &&
      !img.includes("dicebear.com") &&
      !img.includes("gstatic.com")
    );

    if (uniqueImages.length > 0) {
      setNewChapter(prev => ({
        ...prev,
        images: uniqueImages.join('\n')
      }));
      setSourceHtml('');
      alert(`${uniqueImages.length} adet resim başarıyla ayıklandı!`);
    } else {
      alert('Yapıştırılan metinde resim linki bulunamadı.');
    }
  };

  const testImgbbKey = async () => {
    if (!imgbbKey) {
      setUploadError("Lütfen bir API anahtarı girin.");
      return;
    }
    setIsUploading(true);
    setUploadError(null);
    try {
      // We'll try to upload a tiny transparent pixel to test the key
      const testImage = "R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"; // 1x1 transparent gif
      const formData = new FormData();
      formData.append('image', testImage);
      
      const response = await fetch(`https://api.imgbb.com/1/upload?key=${imgbbKey}`, {
        method: 'POST',
        body: formData
      });
      
      const data = await response.json();
      if (data.success) {
        alert("API Anahtarı geçerli! Yükleme yapabilirsiniz.");
      } else {
        throw new Error(data.error?.message || "Geçersiz anahtar.");
      }
    } catch (error: any) {
      setUploadError(`Anahtar Testi Başarısız: ${error.message}`);
    } finally {
      setIsUploading(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    setUploadError(null);
    const uploadedUrls: string[] = [];

    try {
      const uploadPromises = Array.from(files).map(async (file) => {
        // Check file size (max 32MB for ImgBB)
        if (file.size > 32 * 1024 * 1024) {
          throw new Error(`${file.name} çok büyük. Maksimum 32MB yükleyebilirsiniz.`);
        }

        const formData = new FormData();
        formData.append('image', file);
        
        const response = await fetch(`https://api.imgbb.com/1/upload?key=${imgbbKey}`, {
          method: 'POST',
          body: formData
        });
        
        const data = await response.json();
        if (data.success) {
          return data.data.url;
        } else {
          const msg = data.error?.message || "Yükleme başarısız oldu.";
          if (msg.includes("Invalid API")) {
            throw new Error("Geçersiz API Anahtarı. Lütfen yeni bir anahtar alıp kutuya yapıştırın.");
          }
          throw new Error(msg);
        }
      });

      const results = await Promise.all(uploadPromises);
      const successfulUrls = results.filter(url => !!url);

      if (successfulUrls.length > 0) {
        setNewChapter(prev => ({
          ...prev,
          images: prev.images ? `${prev.images}\n${successfulUrls.join('\n')}` : successfulUrls.join('\n')
        }));
      }
    } catch (error: any) {
      console.error("Upload Error:", error);
      setUploadError(error.message || "Resimler yüklenirken bir sorun oluştu.");
    } finally {
      setIsUploading(false);
      // Reset input
      e.target.value = '';
    }
  };

  if (profile?.role !== 'admin') return <div className="text-red-500">Yetkiniz yok.</div>;
  if (!webtoon) return <div className="text-zinc-500">Yükleniyor...</div>;

  const handleAddChapter = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const chapterData: any = {
        webtoonId: id,
        title: newChapter.title,
        number: Number(newChapter.number),
        createdAt: serverTimestamp(),
        publishAt: newChapter.publishAt ? Timestamp.fromDate(new Date(newChapter.publishAt)) : serverTimestamp()
      };

      if (webtoon.type === 'webtoon') {
        chapterData.images = newChapter.images.split('\n')
          .map(url => url.trim())
          .filter(url => url !== '');
      } else {
        chapterData.content = newChapter.content;
      }

      await addDoc(collection(db, `webtoons/${id}/chapters`), chapterData);
      
      // Update webtoon lastChapterAt
      await updateDoc(doc(db, 'webtoons', id), { lastChapterAt: serverTimestamp() });

      // Notify followers
      // const followersSnapshot = await getDocs(query(collection(db, 'favorites'), where('webtoonId', '==', id)));
      // In a real app, this would be a Cloud Function. For this demo, we can simulate it if we had the list.
      // Since we can't easily get all followers without a separate query, we'll skip the actual notification creation here
      // but the UI is ready to show them.

      setShowAddChapter(false);
      setNewChapter({ title: '', number: chapters.length + 2, content: '', images: '', publishAt: '' });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `webtoons/${id}/chapters`);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <Helmet>
        <title>{`${webtoon.title} Yönetimi - WebtoonZ`}</title>
      </Helmet>
      <div className="mb-8 flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-4">
          <Link to="/admin" className="flex h-10 w-10 items-center justify-center rounded-xl bg-zinc-900 text-zinc-500 transition-all hover:bg-zinc-800 hover:text-white">
            <ChevronRight className="h-6 w-6 rotate-180" />
          </Link>
          <div>
            <h1 className="text-2xl font-black text-white font-display tracking-tight leading-none">{webtoon.title}</h1>
            <p className="mt-1 text-xs font-bold text-zinc-500 uppercase tracking-widest">Bölüm Yönetimi</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={generateAISummary}
            disabled={isGeneratingSummary}
            className="flex items-center gap-2 rounded-xl border border-orange-500/30 bg-orange-500/10 px-4 py-2 text-sm font-bold text-orange-500 transition-all hover:bg-orange-500/20 disabled:opacity-50"
          >
            <Sparkles className={cn("h-4 w-4", isGeneratingSummary && "animate-pulse")} />
            {isGeneratingSummary ? 'Özet Oluşturuluyor...' : 'AI Özet Oluştur'}
          </button>
          <button 
            onClick={() => setShowAddChapter(!showAddChapter)}
            className="flex items-center gap-2 rounded-xl bg-orange-600 px-4 py-2 text-sm font-bold text-white transition-all hover:bg-orange-500 shadow-lg shadow-orange-600/20"
          >
            <Plus className="h-4 w-4" />
            Yeni Bölüm Ekle
          </button>
        </div>
      </div>

      {/* Stats Dashboard */}
      <div className="mb-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
        <div className="rounded-2xl border border-zinc-900 bg-zinc-900/30 p-4">
          <p className="text-[10px] font-black uppercase text-zinc-500 tracking-widest">Toplam İzlenme</p>
          <p className="mt-1 text-2xl font-black text-white font-display">{webtoon.viewCount || 0}</p>
        </div>
        <div className="rounded-2xl border border-zinc-900 bg-zinc-900/30 p-4">
          <p className="text-[10px] font-black uppercase text-zinc-500 tracking-widest">Ortalama Puan</p>
          <p className="mt-1 text-2xl font-black text-white font-display">
            {webtoon.ratingCount ? (webtoon.ratingSum! / webtoon.ratingCount!).toFixed(1) : '0.0'}
          </p>
        </div>
        <div className="rounded-2xl border border-zinc-900 bg-zinc-900/30 p-4">
          <p className="text-[10px] font-black uppercase text-zinc-500 tracking-widest">Oy Sayısı</p>
          <p className="mt-1 text-2xl font-black text-white font-display">{webtoon.ratingCount || 0}</p>
        </div>
        <div className="rounded-2xl border border-zinc-900 bg-zinc-900/30 p-4">
          <p className="text-[10px] font-black uppercase text-zinc-500 tracking-widest">Bölüm Sayısı</p>
          <p className="mt-1 text-2xl font-black text-white font-display">{chapters.length}</p>
        </div>
      </div>

      {showAddChapter && (
        <div className="mb-8 flex flex-col gap-6 rounded-xl border border-zinc-800 bg-zinc-900 p-6">
          {/* Image Upload Guide */}
          <div className="rounded-lg bg-orange-500/5 p-4 ring-1 ring-orange-500/20">
            <h3 className="mb-2 flex items-center gap-2 text-sm font-bold text-orange-500">
              <ImageIcon className="h-4 w-4" />
              Resim Linki Nasıl Alınır?
            </h3>
            <p className="text-xs leading-relaxed text-zinc-400">
              Bilgisayarınızdaki resimleri doğrudan kullanamazsınız. Önce internete yükleyip <span className="text-white font-bold">https://</span> ile başlayan bir link almalısınız:
            </p>
            <div className="mt-2 rounded bg-black/40 p-2 text-[10px] text-orange-200/70">
              <p className="font-bold text-orange-400">Önemli İpucu:</p>
              <p>Linkin sonu mutlaka <span className="font-mono text-white">.jpg</span>, <span className="font-mono text-white">.png</span> veya <span className="font-mono text-white">.webp</span> ile bitmelidir. <span className="text-blue-400">/uploads/</span> içeren linkleriniz tam olarak bu formattadır ve en iyi performansı verir.</p>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <a 
                href="https://postimages.org" 
                target="_blank" 
                rel="noopener noreferrer"
                className="rounded-lg bg-zinc-800 px-3 py-1.5 text-[10px] font-bold text-white hover:bg-zinc-700 transition-colors"
              >
                PostImages'a Git
              </a>
              <a 
                href="https://imgur.com/upload" 
                target="_blank" 
                rel="noopener noreferrer"
                className="rounded-lg bg-zinc-800 px-3 py-1.5 text-[10px] font-bold text-white hover:bg-zinc-700 transition-colors"
              >
                Imgur'a Git
              </a>
            </div>
            <p className="mt-2 text-[10px] text-zinc-500 italic">
              * Yükledikten sonra "Doğrudan Bağlantı" (Direct Link) seçeneğini kopyalayıp aşağıya yapıştırın.
            </p>
          </div>

          {/* Album Link Fetcher */}
          <div className="rounded-lg bg-blue-500/5 p-4 ring-1 ring-blue-500/20">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="flex items-center gap-2 text-sm font-bold text-blue-500">
                <Zap className="h-4 w-4" />
                Gelişmiş Resim Çekici
              </h3>
              <div className="flex rounded-lg bg-zinc-950 p-1">
                <button 
                  onClick={() => setFetchMode('link')}
                  className={cn(
                    "rounded-md px-3 py-1 text-[10px] font-bold transition-all",
                    fetchMode === 'link' ? "bg-blue-600 text-white" : "text-zinc-500 hover:text-zinc-300"
                  )}
                >
                  Link ile
                </button>
                <button 
                  onClick={() => setFetchMode('source')}
                  className={cn(
                    "rounded-md px-3 py-1 text-[10px] font-bold transition-all",
                    fetchMode === 'source' ? "bg-blue-600 text-white" : "text-zinc-500 hover:text-zinc-300"
                  )}
                >
                  Kaynak Kod ile
                </button>
                <button 
                  onClick={() => setFetchMode('upload')}
                  className={cn(
                    "rounded-md px-3 py-1 text-[10px] font-bold transition-all",
                    fetchMode === 'upload' ? "bg-blue-600 text-white" : "text-zinc-500 hover:text-zinc-300"
                  )}
                >
                  Dosya Yükle
                </button>
              </div>
            </div>

            {fetchMode === 'link' ? (
              <>
                <p className="mb-3 text-xs text-zinc-400">
                  Albüm linkini buraya yapıştırarak resimleri otomatik çekebilirsiniz.
                </p>
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    placeholder="Albüm Linki (https://...)" 
                    className="flex-1 rounded-lg border border-zinc-800 bg-zinc-950 p-2 text-xs text-white focus:border-blue-500 focus:outline-none"
                    value={albumUrl}
                    onChange={e => setAlbumUrl(e.target.value)}
                  />
                  <button 
                    type="button"
                    onClick={fetchAlbumImages}
                    disabled={isFetchingAlbum || !albumUrl.trim()}
                    className="rounded-lg bg-blue-600 px-4 py-2 text-xs font-bold text-white hover:bg-blue-500 disabled:opacity-50"
                  >
                    {isFetchingAlbum ? 'Çekiliyor...' : 'Resimleri Çek'}
                  </button>
                </div>
              </>
            ) : fetchMode === 'source' ? (
              <>
                <p className="mb-3 text-xs text-zinc-400">
                  Link çalışmıyorsa: Albüm sayfasına gidin, <kbd className="rounded bg-zinc-800 px-1 text-[10px]">Ctrl+U</kbd> yapın, tüm kodu kopyalayıp buraya yapıştırın.
                </p>
                <div className="flex flex-col gap-2">
                  <textarea 
                    placeholder="Sayfa kaynağını (HTML) buraya yapıştırın..." 
                    className="min-h-[100px] w-full rounded-lg border border-zinc-800 bg-zinc-950 p-2 text-xs text-white focus:border-blue-500 focus:outline-none"
                    value={sourceHtml}
                    onChange={e => setSourceHtml(e.target.value)}
                  />
                  <button 
                    type="button"
                    onClick={extractFromSource}
                    disabled={!sourceHtml.trim()}
                    className="w-full rounded-lg bg-blue-600 py-2 text-xs font-bold text-white hover:bg-blue-500 disabled:opacity-50"
                  >
                    Resimleri Ayıkla
                  </button>
                </div>
              </>
            ) : (
              <div className="flex flex-col gap-4">
                <div className="flex flex-col gap-2 rounded-lg bg-zinc-900/50 p-3 ring-1 ring-zinc-800">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">ImgBB API Anahtarı</label>
                    <button 
                      onClick={() => {
                        setImgbbKey("7016335964860d8299298f623098595b");
                        setUploadError(null);
                      }}
                      className="text-[9px] font-bold text-blue-500 hover:underline"
                    >
                      Varsayılana Sıfırla
                    </button>
                  </div>
                  <div className="flex gap-2">
                    <input 
                      type="password" 
                      placeholder="ImgBB API Key" 
                      className={cn(
                        "flex-1 rounded-lg border bg-zinc-950 p-2 text-xs text-white focus:outline-none",
                        uploadError?.includes("API Anahtarı") || uploadError?.includes("Anahtar Testi") ? "border-red-500 focus:border-red-500" : "border-zinc-800 focus:border-blue-500"
                      )}
                      value={imgbbKey}
                      onChange={e => setImgbbKey(e.target.value)}
                    />
                    <button 
                      type="button"
                      onClick={testImgbbKey}
                      disabled={isUploading || !imgbbKey}
                      className="rounded-lg bg-zinc-800 px-3 py-2 text-[10px] font-bold text-zinc-400 hover:bg-zinc-700 hover:text-white transition-all disabled:opacity-50"
                    >
                      Test Et
                    </button>
                  </div>
                  {uploadError && (
                    <div className="rounded-md bg-red-500/10 p-2 border border-red-500/20">
                      <p className="text-[10px] font-bold text-red-500">{uploadError}</p>
                    </div>
                  )}
                  <div className="flex flex-col gap-1">
                    <p className="text-[9px] text-zinc-500">
                      1. <a href="https://imgbb.com/signup" target="_blank" rel="noopener noreferrer" className="text-blue-500 underline font-bold">Buradan</a> ücretsiz hesap açın.
                    </p>
                    <p className="text-[9px] text-zinc-500">
                      2. <a href="https://api.imgbb.com/" target="_blank" rel="noopener noreferrer" className="text-blue-500 underline font-bold">Buradan</a> "Add API Key" butonuna basıp anahtarı kopyalayın.
                    </p>
                    <p className="text-[9px] text-zinc-500">
                      3. Kopyaladığınız anahtarı yukarıdaki kutuya yapıştırın.
                    </p>
                  </div>
                </div>

                <div className="flex flex-col items-center justify-center rounded-xl border-2 border-dashed border-zinc-800 bg-zinc-950/50 py-8 text-center transition-all hover:border-blue-500/50">
                  <input
                    type="file"
                    id="file-upload"
                    multiple
                    accept="image/*"
                    className="hidden"
                    onChange={handleFileUpload}
                    disabled={isUploading}
                  />
                  <label 
                    htmlFor="file-upload" 
                    className={cn(
                      "flex cursor-pointer flex-col items-center gap-3",
                      isUploading && "pointer-events-none opacity-50"
                    )}
                  >
                    <div className="rounded-full bg-blue-500/10 p-4 ring-1 ring-blue-500/20">
                      {isUploading ? (
                        <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
                      ) : (
                        <Upload className="h-8 w-8 text-blue-500" />
                      )}
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-bold text-white">
                        {isUploading ? 'Resimler Yükleniyor...' : 'Resimleri Seçin veya Sürükleyin'}
                      </p>
                      <p className="text-xs text-zinc-500">JPG, PNG veya WebP (Birden fazla seçebilirsiniz)</p>
                    </div>
                  </label>
                </div>
              </div>
            )}
          </div>

          <form onSubmit={handleAddChapter} className="flex flex-col gap-4">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <input 
              required
              placeholder="Bölüm Başlığı" 
              className="rounded-lg border border-zinc-800 bg-zinc-950 p-3 text-white focus:border-orange-500 focus:outline-none"
              value={newChapter.title}
              onChange={e => setNewChapter({...newChapter, title: e.target.value})}
            />
            <input 
              required
              type="number"
              placeholder="Bölüm Numarası" 
              className="rounded-lg border border-zinc-800 bg-zinc-950 p-3 text-white focus:border-orange-500 focus:outline-none"
              value={newChapter.number}
              onChange={e => setNewChapter({...newChapter, number: Number(e.target.value)})}
            />
            <div className="flex flex-col gap-1 md:col-span-2">
              <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Yayınlanma Tarihi (Opsiyonel - Planlama için)</label>
              <input 
                type="datetime-local"
                className="rounded-lg border border-zinc-800 bg-zinc-950 p-3 text-white focus:border-orange-500 focus:outline-none"
                value={newChapter.publishAt}
                onChange={e => setNewChapter({...newChapter, publishAt: e.target.value})}
              />
            </div>
          </div>
          
          {webtoon.type === 'webtoon' ? (
            <div className="flex flex-col gap-4">
              <textarea 
                required
                placeholder="Resim URL'leri (Her satıra bir tane)" 
                className="min-h-[200px] rounded-lg border border-zinc-800 bg-zinc-950 p-3 text-white focus:border-orange-500 focus:outline-none"
                value={newChapter.images}
                onChange={e => setNewChapter({...newChapter, images: e.target.value})}
              />
              {newChapter.images.trim() && (
                <div className="rounded-xl border border-zinc-800 bg-zinc-950 p-4">
                  <h4 className="mb-3 text-[10px] font-black uppercase text-zinc-500 tracking-widest">Resim Önizleme</h4>
                  <div className="grid grid-cols-4 gap-2">
                    {newChapter.images.split('\n').map(u => u.trim()).filter(u => u !== '').slice(0, 8).map((url, i) => (
                      <div key={i} className="relative aspect-[3/4] overflow-hidden rounded-lg bg-zinc-900 ring-1 ring-zinc-800">
                        <img 
                          src={url} 
                          alt="Önizleme" 
                          className="h-full w-full object-cover" 
                          referrerPolicy="no-referrer"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            if (!target.src.includes('/api/proxy-image')) {
                              target.src = `/api/proxy-image?url=${encodeURIComponent(url)}`;
                            } else {
                              target.src = 'https://placehold.co/300x400/09090b/ef4444?text=Hatalı+Link';
                            }
                          }}
                        />
                      </div>
                    ))}
                  </div>
                  <p className="mt-2 text-[10px] text-zinc-500 italic">* Sadece ilk 8 resim önizlenir. Eğer resimler görünmüyorsa link hatalıdır.</p>
                </div>
              )}
            </div>
          ) : (
            <textarea 
              required
              placeholder="Bölüm İçeriği (Markdown/Text)" 
              className="min-h-[300px] rounded-lg border border-zinc-800 bg-zinc-950 p-3 text-white focus:border-orange-500 focus:outline-none"
              value={newChapter.content}
              onChange={e => setNewChapter({...newChapter, content: e.target.value})}
            />
          )}
          
          <button className="rounded-lg bg-orange-600 py-3 font-bold text-white hover:bg-orange-500">Bölümü Yayınla</button>
        </form>
      </div>
    )}

      <div className="grid grid-cols-1 gap-2">
        {chapters.map(ch => (
          <div key={ch.id} className="flex items-center justify-between rounded-lg bg-zinc-900/50 p-4 ring-1 ring-zinc-800">
            <span className="font-bold text-white">Bölüm {ch.number}: {ch.title}</span>
            <button 
              onClick={async () => {
                try {
                  await deleteDoc(doc(db, `webtoons/${id}/chapters`, ch.id));
                } catch (error) {
                  handleFirestoreError(error, OperationType.DELETE, `webtoons/${id}/chapters/${ch.id}`);
                }
              }}
              className="text-zinc-500 hover:text-red-500"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [globalError, setGlobalError] = useState<FirestoreErrorInfo | null>(null);

  useEffect(() => {
    const handleError = (e: any) => {
      const err = e.detail as FirestoreErrorInfo;
      if (err.error.includes('Quota exceeded') || err.error.includes('quota')) {
        setGlobalError(err);
      }
    };
    window.addEventListener('firestore-error', handleError);
    return () => window.removeEventListener('firestore-error', handleError);
  }, []);

  useEffect(() => {
    let unsubscribeProfile: (() => void) | null = null;
    const unsubscribeAuth = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      
      // Clean up previous profile listener if it exists
      if (unsubscribeProfile) {
        unsubscribeProfile();
        unsubscribeProfile = null;
      }

      if (firebaseUser) {
        getDoc(doc(db, 'users', firebaseUser.uid)).then((snapshot) => {
          if (snapshot.exists()) {
            setProfile({ uid: firebaseUser.uid, ...snapshot.data() } as UserProfile);
          } else {
            // Create profile
            const isDefaultAdmin = firebaseUser.email === 'ramaznkeskn@gmail.com';
            const newProfile: any = {
              email: firebaseUser.email,
              displayName: firebaseUser.displayName || firebaseUser.email?.split('@')[0],
              photoURL: firebaseUser.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${firebaseUser.uid}`,
              role: isDefaultAdmin ? 'admin' : 'user',
              createdAt: serverTimestamp()
            };
            setDoc(doc(db, 'users', firebaseUser.uid), newProfile).then(() => {
              setProfile({ uid: firebaseUser.uid, ...newProfile });
            });
          }
          setLoading(false);
        }).catch((error) => {
          if (auth.currentUser) {
            handleFirestoreError(error, OperationType.GET, `users/${firebaseUser.uid}`);
          }
          setLoading(false);
        });
      } else {
        setProfile(null);
        setLoading(false);
      }
    });
    return () => {
      unsubscribeAuth();
    };
  }, []);

  if (globalError) {
    return (
      <Router>
        <div className="min-h-screen bg-zinc-950 text-zinc-100 selection:bg-orange-500/30">
          <Navbar user={user} profile={profile} />
          <main className="container mx-auto px-4 py-8">
            <QuotaErrorDisplay />
          </main>
        </div>
      </Router>
    );
  }

  if (loading) return <div className="flex h-screen items-center justify-center bg-black text-zinc-500">Yükleniyor...</div>;

  return (
    <Router>
      <Helmet>
        <title>WebtoonZ - Ücretsiz Webtoon ve Roman Okuma Platformu</title>
        <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23ea580c' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z'></path><path d='M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z'></path></svg>" />
      </Helmet>
      <ScrollToTop />
      <div className="min-h-screen bg-zinc-950 text-zinc-200">
        <Navbar user={user} profile={profile} />
        <main>
          <Routes>
            <Route path="/" element={<HomePage user={user} />} />
            <Route path="/webtoon/:id" element={<WebtoonDetail user={user} profile={profile} />} />
            <Route path="/webtoon/:id/chapter/:chapterId" element={<ChapterReader user={user} profile={profile} />} />
            <Route path="/profile" element={<ProfilePage user={user} profile={profile} />} />
            <Route path="/admin" element={<AdminPanel profile={profile} />} />
            <Route path="/admin/webtoon/:id" element={<AdminWebtoonDetail profile={profile} />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}
