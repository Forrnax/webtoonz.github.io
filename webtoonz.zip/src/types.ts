export interface Webtoon {
  id: string;
  title: string;
  description: string;
  coverUrl: string;
  author: string;
  type: 'webtoon' | 'novel';
  createdAt: any;
  updatedAt: any;
  status: 'ongoing' | 'completed' | 'hiatus';
  genres: string[];
  viewCount?: number;
  ratingSum?: number;
  ratingCount?: number;
  scheduleDay?: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday' | 'Sunday' | 'None';
  lastChapterAt?: any;
}

export interface Chapter {
  id: string;
  webtoonId: string;
  title: string;
  number: number;
  content?: string; // For novels
  images?: string[]; // For webtoons
  createdAt: any;
  publishAt?: any; // Scheduled publishing
  likeCount?: number;
}

export interface Comment {
  id: string;
  targetId: string;
  userId: string;
  userName: string;
  userPhoto: string;
  text: string;
  createdAt: any;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  bio?: string;
  bannerURL?: string;
  role: 'admin' | 'user';
  settings?: {
    fontSize: number;
    fontFamily: string;
    theme: 'light' | 'dark' | 'sepia';
  };
}

export interface Favorite {
  id: string;
  userId: string;
  webtoonId: string;
  createdAt: any;
}

export interface Rating {
  id: string;
  userId: string;
  webtoonId: string;
  score: number;
  createdAt: any;
}

export interface Progress {
  id: string;
  userId: string;
  webtoonId: string;
  chapterId: string;
  chapterNumber: number;
  updatedAt: any;
}

export interface ChapterLike {
  id: string;
  userId: string;
  chapterId: string;
  createdAt: any;
}

export interface AppNotification {
  id: string;
  userId: string;
  webtoonId: string;
  webtoonTitle: string;
  chapterNumber: number;
  isRead: boolean;
  createdAt: any;
}
